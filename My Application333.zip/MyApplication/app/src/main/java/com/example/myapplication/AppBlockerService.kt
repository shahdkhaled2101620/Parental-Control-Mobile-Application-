package com.example.myapplication
import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.accessibilityservice.AccessibilityServiceInfo
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import android.view.LayoutInflater
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class AppBlockerService : AccessibilityService() {

    private lateinit var selectedPackages: Set<String>
    private var isPasswordDialogShowing = false
    private var lastBlockedPackage: String? = null
    private var currentlyUnlockedPackage: String? = null

    private lateinit var systemAndLauncherPackages: Set<String>

    override fun onCreate() {
        super.onCreate()
        systemAndLauncherPackages = setOf(
            this.packageName,
            "com.android.systemui",
            "com.android.launcher",
            "com.google.android.apps.nexuslauncher",
            "com.sec.android.app.launcher",
            "com.miui.home",
            "com.huawei.android.launcher",
            "com.android.settings",
            "com.google.android.inputmethod.latin",
            "android",
            "com.android.vending",
            "com.google.android.gms",
            "com.google.android.permissioncontroller",
            "com.android.packageinstaller",
            "com.google.android.apps.wellbeing",
            "com.samsung.android.app.galaxyfinder",
            "com.samsung.android.app.taskedge",
            "com.samsung.android.app.genie",
            "com.android.chrome",
            "com.android.incallui",
            "com.google.android.dialer",
            "com.samsung.android.app.contacts",
            "com.android.contacts",
            "com.samsung.android.messaging",
            "com.google.android.apps.messaging",
            "com.samsung.android.calendar",
            "com.google.android.calendar",
            "com.samsung.android.app.filter",
            "com.android.documentsui",
            "com.android.providers.media",
            "com.android.camera",
            "com.samsung.android.app.camera",
            "com.google.android.googlequicksearchbox",
            "com.google.android.launcher",
            "com.android.launcher3",
            "com.oneplus.android.launcher",
            "com.oppo.launcher",
            "com.vivo.launcher",
            "com.htc.launcher",
            "com.lge.launcher",
            "com.sonymobile.home",
            "com.samsung.android.app.lockscreen",
            "com.sec.android.app.sbrowser",
            "com.samsung.android.honeyboard",
            "com.google.android.inputmethod.latin.debug",
            "com.touchtype.swiftkey",
            "com.nuance.swype.dtc",
            "com.sec.android.inputmethod",
            "com.google.android.apps.assistant",
            "com.google.android.googlequicksearchbox"
        )
        loadSelectedPackages()
        Log.d("AppBlockerService", "Service created. Selected packages: $selectedPackages")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return

        val prefs = getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
        val isChildModeActive = prefs.getBoolean("isChildModeActive", false)

        if (!isChildModeActive) {
            Log.d("AppBlockerService", "Child mode is disabled. Allowing all apps.")
            lastBlockedPackage = null
            currentlyUnlockedPackage = null
            return
        }

        if (isPasswordDialogShowing) {
            Log.d("AppBlockerService", "Password dialog is showing. Skipping event processing.")
            return
        }

        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
            event.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) {
            loadSelectedPackages()
        }

        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            val packageName = event.packageName?.toString()
            Log.d("AppBlockerService", "Window state changed to: $packageName")

            if (packageName != null && selectedPackages.isNotEmpty()) {
                if (systemAndLauncherPackages.contains(packageName)) {
                    Log.d("AppBlockerService", "Ignoring system/launcher/self package: $packageName")
                    lastBlockedPackage = null
                    return
                }

                if (packageName == currentlyUnlockedPackage) {
                    Log.d("AppBlockerService", "Allowing currently unlocked app (session): $packageName")
                    lastBlockedPackage = null
                    return
                }

                if (selectedPackages.contains(packageName)) {
                    Log.d("AppBlockerService", "Allowing parent-selected app: $packageName")
                    lastBlockedPackage = null
                    currentlyUnlockedPackage = null
                    return
                }

                Log.d("AppBlockerService", "Blocking unselected app: $packageName")
                currentlyUnlockedPackage = null

                if (!isPasswordDialogShowing || lastBlockedPackage != packageName) {
                    lastBlockedPackage = packageName
                    showPasswordDialog(packageName)
                } else {
                    Log.d("AppBlockerService", "Password dialog already showing or package already blocked: $packageName. Redirecting to KidsLauncher.")
                    returnToKidsLauncher()
                }
            }
        }
    }

    override fun onInterrupt() {
        Log.d("AppBlockerService", "Accessibility service interrupted.")
        isPasswordDialogShowing = false
        lastBlockedPackage = null
        currentlyUnlockedPackage = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        val info = AccessibilityServiceInfo()
        info.eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
        info.feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
        info.flags = AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS or
                AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS or
                AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
        info.notificationTimeout = 100
        this.serviceInfo = info
        Log.d("AppBlockerService", "Accessibility service connected.")
    }

    private fun showPasswordDialog(blockedPackage: String) {
        if (isPasswordDialogShowing) return

        isPasswordDialogShowing = true

        val dialogView = LayoutInflater.from(this).inflate(R.layout.custom_password_dialog, null)

        val builder = AlertDialog.Builder(this)
            .setView(dialogView)
            .setCancelable(false)

        val dialog = builder.create()

        val passwordInput = dialogView.findViewById<EditText>(R.id.passwordInput)
        val confirmButton = dialogView.findViewById<Button>(R.id.confirmButton)
        val cancelButton = dialogView.findViewById<Button>(R.id.cancelButton)

        confirmButton.setOnClickListener {
            val enteredPassword = passwordInput.text.toString()
            val savedPassword = getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
                .getString("parent_password", null)

            if (enteredPassword == savedPassword) {
                Toast.makeText(this, "كلمة المرور صحيحة. يمكنك استخدام التطبيق.", Toast.LENGTH_SHORT).show()
                try {
                    currentlyUnlockedPackage = blockedPackage
                    val launchIntent = packageManager.getLaunchIntentForPackage(blockedPackage)
                    launchIntent?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(launchIntent)
                } catch (e: Exception) {
                    Log.e("AppBlockerService", "Failed to launch app: $blockedPackage", e)
                    Toast.makeText(this, "تعذر فتح التطبيق.", Toast.LENGTH_SHORT).show()
                    returnToKidsLauncher()
                }
            } else {
                Toast.makeText(this, "كلمة المرور غير صحيحة. لا يمكن فتح التطبيق.", Toast.LENGTH_SHORT).show()
                returnToKidsLauncher()
            }
            dialog.dismiss()
            isPasswordDialogShowing = false
        }

        cancelButton.setOnClickListener {
            Toast.makeText(this, "تم إلغاء العملية.", Toast.LENGTH_SHORT).show()
            returnToKidsLauncher()
            dialog.dismiss()
            isPasswordDialogShowing = false
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            dialog.window?.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY)
        } else {
            @Suppress("DEPRECATION")
            dialog.window?.setType(WindowManager.LayoutParams.TYPE_SYSTEM_ALERT)
        }
        dialog.show()
    }

    private fun loadSelectedPackages() {
        val prefs = getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
        val selectedPackagesString = prefs.getString("selected_packages_set", null)
        selectedPackages = selectedPackagesString?.split(",")?.toSet() ?: emptySet()
        Log.d("AppBlockerService", "Loaded selected packages: $selectedPackages")
    }

    private fun returnToKidsLauncher() {
        val intent = Intent(this, KidsLauncher::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        startActivity(intent)
    }
}