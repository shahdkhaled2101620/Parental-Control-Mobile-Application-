package com.example.myapplication

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.activity.result.contract.ActivityResultContracts
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.asRequestBody
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

class add_child1 : AppCompatActivity() {

    private lateinit var imageView9: ImageView // الصورة الدائرية الكبيرة (صورة البروفايل)
    private lateinit var imageView11: ImageView // أيقونة القلم (لفتح الجاليري)
    private lateinit var parentNameTextView: TextView
    private var selectedImageUri: Uri? = null

    private val client = OkHttpClient()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_child1)

        imageView9 = findViewById(R.id.imageView9) // تهيئة الصورة الدائرية الكبيرة
        imageView11 = findViewById(R.id.imageView11) // تهيئة أيقونة القلم
        parentNameTextView = findViewById(R.id.textView10)

        val sharedPref = getSharedPreferences("user_prefs", Context.MODE_PRIVATE)
        val fullName = sharedPref.getString("full_name", "User")
        parentNameTextView.text = fullName

        // تغيير: الآن أيقونة القلم هي التي تفتح الجاليري
        imageView11.setOnClickListener {
            openGallery()
        }
        // ملاحظة: لم يعد لـ imageView9 مستمع نقر خاص به لفتح الجاليري

        findViewById<ImageView>(R.id.info_icon).setOnClickListener {
            startActivity(Intent(this, about_screen::class.java))
        }

        findViewById<Button>(R.id.button5).setOnClickListener {
            startActivity(Intent(this, Kidinformation::class.java))
        }

        findViewById<Button>(R.id.button6).setOnClickListener {
            startActivity(Intent(this, MainActivity2::class.java))
        }
    }

    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let {
            imageView9.setImageURI(it) // الصورة تظهر في imageView9 (الدائرة الكبيرة)
            selectedImageUri = it
            uploadParentImage() // يتم رفع الصورة بعد اختيارها وعرضها
        }
    }

    private fun openGallery() {
        pickImage.launch("image/*")
    }

    private fun uploadParentImage() {
        if (selectedImageUri == null) {
            Toast.makeText(this, "الرجاء اختيار صورة أولاً", Toast.LENGTH_SHORT).show()
            return
        }

        val imageFile = uriToFile(selectedImageUri!!)
        if (imageFile == null || !imageFile.exists()) {
            Toast.makeText(this, "فشل في قراءة ملف الصورة", Toast.LENGTH_SHORT).show()
            return
        }

        // جلب parent_id من SharedPreferences
        val prefs = getSharedPreferences("user_prefs", Context.MODE_PRIVATE)
        val parentId = prefs.getInt("parent_id", -1)
        if (parentId == -1) {
            Toast.makeText(this, "معرف المستخدم غير موجود، يرجى تسجيل الدخول مجدداً", Toast.LENGTH_LONG).show()
            return
        }

        val url = "http://168.231.108.230/ParentalCo/upload_parent_image.php"

        val requestBody = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart(
                "image",
                imageFile.name,
                imageFile.asRequestBody("image/jpeg".toMediaTypeOrNull()) // تأكد نوع الصورة هنا إذا PNG أو GIF حسب الحاجة
            )
            .addFormDataPart("parent_id", parentId.toString())
            .build()

        val request = Request.Builder()
            .url(url)
            .post(requestBody)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    Toast.makeText(this@add_child1, "فشل رفع الصورة: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val responseBody = response.body?.string()
                runOnUiThread {
                    if (response.isSuccessful) {
                        // يمكنك عرض رسالة أكثر تفصيلا إذا أردت
                        Toast.makeText(this@add_child1, "تم رفع صورة الأب بنجاح", Toast.LENGTH_LONG).show()
                    } else {
                        Toast.makeText(this@add_child1, "فشل رفع الصورة: رمز ${response.code}\n$responseBody", Toast.LENGTH_LONG).show()
                    }
                }
                println("Server response: $responseBody")
            }
        })
    }

    private fun uriToFile(uri: Uri): File? {
        val contentResolver = applicationContext.contentResolver
        val fileName = "parent_image_temp.jpg"
        val file = File(cacheDir, fileName)

        return try {
            contentResolver.openInputStream(uri)?.use { inputStream ->
                FileOutputStream(file).use { outputStream ->
                    inputStream.copyTo(outputStream)
                }
            }
            file
        } catch (e: IOException) {
            e.printStackTrace()
            null
        }
    }
}