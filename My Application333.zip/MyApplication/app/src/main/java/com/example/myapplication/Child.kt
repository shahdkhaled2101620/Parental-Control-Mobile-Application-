package com.example.myapplication
data class Child(var title: String, var image: Int )
