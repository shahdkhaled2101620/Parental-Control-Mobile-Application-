package com.example.myapplication

import android.os.CountDownTimer

data class App(
    var timer: String,
    val icon: Int,
    var isTimerRunning: Boolean = false,
    var remainingTimeInMillis: Long = 0,
    var countDownTimer: CountDownTimer? = null
)
