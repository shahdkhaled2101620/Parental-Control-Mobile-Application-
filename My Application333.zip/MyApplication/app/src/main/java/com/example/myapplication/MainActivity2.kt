package com.example.myapplication

import android.Manifest
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import android.view.View
import android.view.accessibility.AccessibilityManager
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.SwitchCompat
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.Request
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MainActivity2 : AppCompatActivity(), OnItemDeleteListener {
    private var recyclerView: RecyclerView? = null
    private var recyclerViewChildAdapter: RecyclerViewChildAdapter? = null
    private var childList = mutableListOf<Child>()
    private lateinit var addCardButton: Button
    private lateinit var editProfileImageView: ImageView
    private lateinit var dailyTimeButton: Button
    private lateinit var setPasswordButton: Button
    private lateinit var passwordInputSection: LinearLayout
    private lateinit var newPasswordEditText: EditText
    private lateinit var confirmPasswordEditText: EditText
    private lateinit var savePasswordButton: Button
    private lateinit var parentNameTextView: TextView
    private var dailyTimeLimitMillis: Long = 0L
    private lateinit var switchChildActive: SwitchCompat
    private lateinit var previewView: PreviewView
    private var imageCapture: ImageCapture? = null
    private lateinit var cameraExecutor: ExecutorService
    private var isCameraActive = false
    private var currentParentId: String = ""

    private val addChildLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK) {
            val data: Intent? = result.data
            val newChildName = data?.getStringExtra("new_child_name")
            newChildName?.let {
                addNewChild(it)
                Toast.makeText(this, "Child '$it' added successfully!", Toast.LENGTH_SHORT).show()
            }
        } else if (result.resultCode == RESULT_CANCELED) {
            Toast.makeText(this, "Adding child cancelled or failed.", Toast.LENGTH_SHORT).show()
        }
    }

    private val dailyTimeLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK) {
            val data: Intent? = result.data
            dailyTimeLimitMillis = data?.getLongExtra("DAILY_TIME", 0L) ?: 0L
            val minutes = dailyTimeLimitMillis / 1000 / 60
            Toast.makeText(this, "Daily time limit set to: $minutes minutes", Toast.LENGTH_SHORT).show()
            Log.d("MainActivity2", "Daily time limit set to: $dailyTimeLimitMillis ms")
        }
    }

    private val pickImageLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            editProfileImageView.setImageURI(uri)
            Toast.makeText(this, "Image selected: $uri", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "No image selected.", Toast.LENGTH_SHORT).show()
        }
    }

    private val requestCameraPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
        if (isGranted) {
            startCamera()
        } else {
            Toast.makeText(this, "يلزم إذن الكاميرا لتمكين هذه الميزة.", Toast.LENGTH_LONG).show()
            switchChildActive.isChecked = false
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main2)

        checkAccessibilityPermission()

        val infoImageView = findViewById<ImageView>(R.id.imageView3)
        infoImageView.setOnClickListener {
            val intent = Intent(this, about_screen::class.java)
            startActivity(intent)
        }

        recyclerView = findViewById(R.id.childrenlist)
        recyclerViewChildAdapter = RecyclerViewChildAdapter(this, childList, this)
        recyclerView?.layoutManager = LinearLayoutManager(this)
        recyclerView?.adapter = recyclerViewChildAdapter

        prepareChildListData()

        addCardButton = findViewById(R.id.addCardButton)
        addCardButton.setOnClickListener {
            val intent = Intent(this, Kidinformation::class.java)
            addChildLauncher.launch(intent)
        }

        editProfileImageView = findViewById(R.id.imageView5)
        editProfileImageView.setOnClickListener {
            openGallery()
        }

        parentNameTextView = findViewById(R.id.textView)
        val sharedPref = getSharedPreferences("user_prefs", Context.MODE_PRIVATE)
        val fullName = sharedPref.getString("full_name", "الوالد")
        parentNameTextView.text = fullName

        val defaultParentIdInt = -1
        val retrievedParentIdInt = sharedPref.getInt("parent_id", defaultParentIdInt)
        currentParentId = if (retrievedParentIdInt != defaultParentIdInt) {
            retrievedParentIdInt.toString()
        } else {
            "default_parent_id"
        }

        if (currentParentId == "default_parent_id") {
            Log.w("MainActivity2", "Parent ID not found in SharedPreferences or invalid. Using default.")
            Toast.makeText(this, "Parent ID is not set. Please log in again.", Toast.LENGTH_LONG).show()
        }

        dailyTimeButton = findViewById(R.id.dailyTimeButton)
        dailyTimeButton.setOnClickListener {
            val intent = Intent(this, DailyTime::class.java)
            dailyTimeLauncher.launch(intent)
        }

        setPasswordButton = findViewById(R.id.setPasswordButton)
        passwordInputSection = findViewById(R.id.passwordInputSection)
        newPasswordEditText = findViewById(R.id.newPasswordEditText)
        confirmPasswordEditText = findViewById(R.id.confirmPasswordEditText)
        savePasswordButton = findViewById(R.id.savePasswordButton)

        setPasswordButton.setOnClickListener {
            if (passwordInputSection.visibility == View.GONE) {
                passwordInputSection.visibility = View.VISIBLE
                newPasswordEditText.setText("")
                confirmPasswordEditText.setText("")
            } else {
                passwordInputSection.visibility = View.GONE
            }
        }

        savePasswordButton.setOnClickListener {
            val newPassword = newPasswordEditText.text.toString()
            val confirmPassword = confirmPasswordEditText.text.toString()

            if (newPassword.isEmpty() || confirmPassword.isEmpty()) {
                Toast.makeText(this, "الرجاء إدخال وتأكيد كلمة المرور.", Toast.LENGTH_SHORT).show()
            } else if (newPassword != confirmPassword) {
                Toast.makeText(this, "كلمات المرور غير متطابقة. الرجاء المحاولة مرة أخرى.", Toast.LENGTH_SHORT).show()
            } else {
                val prefs = getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
                prefs.edit().putString("parent_password", newPassword).apply()
                Toast.makeText(this, "تم حفظ كلمة مرور الوالدين بنجاح!", Toast.LENGTH_SHORT).show()
                Log.d("MainActivity2", "Parent password saved: $newPassword")
                passwordInputSection.visibility = View.GONE
            }
        }

        switchChildActive = findViewById(R.id.switchChildActive)
        previewView = findViewById(R.id.previewView)
        cameraExecutor = Executors.newSingleThreadExecutor()

        switchChildActive.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                checkCameraPermissionAndOpenCamera()
            } else {
                stopCamera()
                previewView.visibility = View.GONE
                isCameraActive = false
                val prefs = getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
                prefs.edit().putBoolean("isChildModeActive", false).apply()
                Toast.makeText(this, "تم تعطيل وضع الطفل.", Toast.LENGTH_SHORT).show()
            }
        }

        showDefaultLauncherPromptDialog()

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    private fun checkAccessibilityPermission() {
        val accessibilityEnabled = try {
            val accessibilityManager = getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
            accessibilityManager.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_GENERIC)
                .any { it.resolveInfo.serviceInfo.packageName == packageName }
        } catch (e: Exception) {
            false
        }

        if (!accessibilityEnabled) {
            AlertDialog.Builder(this)
                .setTitle("تفعيل خدمة الإمكانية")
                .setMessage("يرجى تفعيل خدمة Accessibility لتطبيقنا لتفعيل وضع الطفل.")
                .setPositiveButton("الذهاب إلى الإعدادات") { _, _ ->
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                }
                .setNegativeButton("إلغاء") { dialog, _ -> dialog.dismiss() }
                .show()
        }
    }

    private fun showDefaultLauncherPromptDialog() {
        val packageName = packageName
        val defaultHomePackage = packageManager.resolveActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName

        if (defaultHomePackage != packageName) {
            AlertDialog.Builder(this)
                .setTitle("تفعيل المشغل الافتراضي")
                .setMessage("هل ترغب في جعل هذا التطبيق المشغل الافتراضي لجهازك؟ هذا سيساعد في تفعيل وضع الطفل تلقائيًا عند العودة إلى الشاشة الرئيسية أو فتح الجهاز.")
                .setPositiveButton("فعّل الآن") { dialog, _ ->
                    try {
                        val intent = Intent(Settings.ACTION_HOME_SETTINGS)
                        startActivity(intent)
                    } catch (e: Exception) {
                        Toast.makeText(this, "لا يمكن فتح إعدادات المشغل الافتراضي.", Toast.LENGTH_LONG).show()
                        Log.e("MainActivity2", "Error opening home settings: ${e.message}")
                    }
                    dialog.dismiss()
                }
                .setNegativeButton("لاحقًا") { dialog, _ ->
                    dialog.dismiss()
                }
                .setCancelable(false)
                .show()
        }
    }

    private fun prepareChildListData() {
        fetchChildrenFromApi()
    }

    private fun fetchChildrenFromApi() {
        val sharedPref = getSharedPreferences("user_prefs", Context.MODE_PRIVATE)
        val defaultParentIdInt = -1
        val parentId = sharedPref.getInt("parent_id", defaultParentIdInt)

        if (parentId == defaultParentIdInt) {
            Toast.makeText(this, "Parent ID غير موجود. الرجاء تسجيل الدخول مرة أخرى.", Toast.LENGTH_LONG).show()
            Log.e("MainActivity2", "Invalid parent ID: $parentId")
            return
        }

        val url = "http://168.231.108.230/ParentalCo/get_children.php?parent_id=$parentId"
        val requestQueue = Volley.newRequestQueue(this)

        val jsonRequest = JsonObjectRequest(Request.Method.GET, url, null,
            { response ->
                try {
                    val status = response.getString("status").trim().lowercase()
                    if (status == "success") {
                        val childrenArray = response.getJSONArray("data")
                        childList.clear()

                        for (i in 0 until childrenArray.length()) {
                            val childObject = childrenArray.getJSONObject(i)
                            val fullName = childObject.getString("Full_Name")
                            val newChild = Child(fullName, R.drawable.user_alt_fill)
                            childList.add(newChild)
                        }

                        recyclerViewChildAdapter?.notifyDataSetChanged()
                        Log.d("MainActivity2", "Children loaded successfully: ${childList.size} children")
                        Toast.makeText(this, "تم تحميل بيانات الأطفال بنجاح!", Toast.LENGTH_SHORT).show()
                    } else {
                        val message = response.optString("message", "خطأ في جلب البيانات")
                        Toast.makeText(this, "فشل تحميل الأطفال: $message", Toast.LENGTH_LONG).show()
                        Log.e("MainActivity2", "API error: $message")
                    }
                } catch (e: Exception) {
                    Toast.makeText(this, "خطأ في معالجة البيانات: ${e.message}", Toast.LENGTH_LONG).show()
                    Log.e("MainActivity2", "JSON parsing error: ${e.message}", e)
                }
            },
            { error ->
                Toast.makeText(this, "خطأ في الاتصال بالخادم: ${error.message}", Toast.LENGTH_LONG).show()
                Log.e("MainActivity2", "Network error: ${error.message}", error)
            })

        requestQueue.add(jsonRequest)
    }

    private fun deleteChildFromServer(name: String, position: Int) {
        val sharedPref = getSharedPreferences("user_prefs", Context.MODE_PRIVATE)
        val defaultParentIdInt = -1
        val parentId = sharedPref.getInt("parent_id", defaultParentIdInt)

        if (parentId == defaultParentIdInt) {
            Toast.makeText(this, "Parent ID غير موجود. الرجاء تسجيل الدخول مرة أخرى.", Toast.LENGTH_LONG).show()
            Log.e("MainActivity2", "Invalid parent ID for deletion: $parentId")
            return
        }

        val url = "http://168.231.108.230/ParentalCo/delete_child.php"
        val requestQueue = Volley.newRequestQueue(this)

        val jsonBody = JSONObject().apply {
            put("full_name", name)
            put("parent_id", parentId)
        }

        val jsonRequest = JsonObjectRequest(Request.Method.POST, url, jsonBody,
            { response ->
                try {
                    val status = response.getString("status").trim().lowercase()
                    if (status == "success") {
                        childList.removeAt(position)
                        recyclerViewChildAdapter?.notifyItemRemoved(position)
                        Toast.makeText(this, "تم حذف الطفل '$name' بنجاح!", Toast.LENGTH_SHORT).show()
                        Log.d("MainActivity2", "Child '$name' deleted successfully from server")
                    } else {
                        val message = response.optString("message", "خطأ في الحذف")
                        Toast.makeText(this, "فشل حذف الطفل: $message", Toast.LENGTH_LONG).show()
                        Log.e("MainActivity2", "API deletion error: $message")
                    }
                } catch (e: Exception) {
                    Toast.makeText(this, "خطأ في معالجة استجابة الحذف: ${e.message}", Toast.LENGTH_LONG).show()
                    Log.e("MainActivity2", "JSON parsing error during deletion: ${e.message}", e)
                }
            },
            { error ->
                Toast.makeText(this, "خطأ في الاتصال بالخادم: ${error.message}", Toast.LENGTH_LONG).show()
                Log.e("MainActivity2", "Network error during deletion: ${error.message}", error)
            })

        requestQueue.add(jsonRequest)
    }

    private fun addNewChild(name: String) {
        val newChild = Child(name, R.drawable.user_alt_fill)
        childList.add(newChild)
        recyclerViewChildAdapter?.notifyItemInserted(childList.size - 1)
        recyclerView?.smoothScrollToPosition(childList.size - 1)
    }

    override fun onItemDelete(position: Int) {
        if (position in 0 until childList.size) {
            childList.removeAt(position)
            recyclerViewChildAdapter?.notifyItemRemoved(position)
            Toast.makeText(this, "Child deleted", Toast.LENGTH_SHORT).show()
        }
    }

    fun onImageClickDelete(name: String, position: Int) { // إزالة override
        deleteChildFromServer(name, position)
    }

    private fun openGallery() {
        pickImageLauncher.launch("image/*")
    }

    private fun checkCameraPermissionAndOpenCamera() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startCamera()
        } else {
            requestCameraPermission.launch(Manifest.permission.CAMERA)
        }
    }

    private fun startCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)

        cameraProviderFuture.addListener({
            val cameraProvider: ProcessCameraProvider = cameraProviderFuture.get()

            val preview = Preview.Builder()
                .build()
                .also {
                    it.setSurfaceProvider(previewView.surfaceProvider)
                }

            imageCapture = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                .build()

            val cameraSelector = CameraSelector.DEFAULT_FRONT_CAMERA

            try {
                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(
                    this, cameraSelector, preview, imageCapture
                )
                previewView.visibility = View.VISIBLE
                isCameraActive = true
                Toast.makeText(this, "الكاميرا جاهزة. تلتقط صورة تلقائيًا...", Toast.LENGTH_SHORT).show()
                previewView.postDelayed({
                    takePhoto()
                }, 1000)
            } catch (exc: Exception) {
                Log.e("MainActivity2", "Use case binding failed", exc)
                Toast.makeText(this, "خطأ في فتح الكاميرا: ${exc.message}", Toast.LENGTH_LONG).show()
                switchChildActive.isChecked = false
                previewView.visibility = View.GONE
                isCameraActive = false
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun takePhoto() {
        val imageCapture = imageCapture ?: run {
            Log.e("MainActivity2", "Image capture use case is null. Cannot take photo.")
            Toast.makeText(this@MainActivity2, "الكاميرا ليست جاهزة لالتقاط الصورة.", Toast.LENGTH_SHORT).show()
            switchChildActive.isChecked = false
            previewView.visibility = View.GONE
            isCameraActive = false
            return
        }

        imageCapture.takePicture(
            ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageCapturedCallback() {
                override fun onCaptureSuccess(image: androidx.camera.core.ImageProxy) {
                    val bitmap = imageProxyToBitmap(image)
                    image.close()
                    bitmap?.let {
                        sendImageToVerificationServer(it, currentParentId)
                    } ?: run {
                        Toast.makeText(this@MainActivity2, "فشل تحويل الصورة.", Toast.LENGTH_SHORT).show()
                        switchChildActive.isChecked = false
                        previewView.visibility = View.GONE
                        isCameraActive = false
                    }
                }

                override fun onError(exception: ImageCaptureException) {
                    Log.e("MainActivity2", "Photo capture failed: ${exception.message}", exception)
                    Toast.makeText(this@MainActivity2, "فشل التقاط الصورة: ${exception.message}", Toast.LENGTH_LONG).show()
                    switchChildActive.isChecked = false
                    previewView.visibility = View.GONE
                    isCameraActive = false
                }
            }
        )
    }

    private fun imageProxyToBitmap(image: androidx.camera.core.ImageProxy): Bitmap? {
        val buffer = image.planes[0].buffer
        val bytes = ByteArray(buffer.remaining())
        buffer.get(bytes)
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
    }

    private fun sendImageToVerificationServer(bitmap: Bitmap, parentId: String) {
        previewView.visibility = View.GONE
        isCameraActive = false

        val filesDir = applicationContext.filesDir
        val file = File(filesDir, "image_to_upload.jpeg")
        val bos = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 80, bos)
        val bitmapdata = bos.toByteArray()

        try {
            val fos = FileOutputStream(file)
            fos.write(bitmapdata)
            fos.flush()
            fos.close()
            Log.d("MainActivity2", "Bitmap saved to temporary file: ${file.absolutePath}")
        } catch (e: Exception) {
            Log.e("MainActivity2", "Error writing bitmap to file: ${e.message}", e)
            Toast.makeText(this@MainActivity2, "فشل إعداد ملف الصورة.", Toast.LENGTH_SHORT).show()
            switchChildActive.isChecked = false
            previewView.visibility = View.GONE
            isCameraActive = false
            stopCamera()
            return
        }

        val requestFile = file.asRequestBody("image/jpeg".toMediaTypeOrNull())
        val imagePart = MultipartBody.Part.createFormData("image", file.name, requestFile)
        val parentIdPart = parentId.toRequestBody("text/plain".toMediaTypeOrNull())

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val response = RetrofitClient.apiService.verifyImage(imagePart, parentIdPart)
                launch(Dispatchers.Main) {
                    val prefs = getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
                    val editor = prefs.edit()
                    if (response.verified) {
                        if (response.matchedWith.contains("Parent", ignoreCase = true)) {
                            Toast.makeText(this@MainActivity2, "تم التحقق: هذا الوالد.", Toast.LENGTH_LONG).show()
                            editor.putBoolean("isChildModeActive", false).apply()
                            switchChildActive.isChecked = false
                        } else if (response.matchedWith.contains("Child", ignoreCase = true)) {
                            Toast.makeText(this@MainActivity2, "تم التحقق: هذا طفل.", Toast.LENGTH_LONG).show()
                            response.image?.let { imageUrl ->
                                Log.d("MainActivity2", "Child image URL from server: $imageUrl")
                            }
                            editor.putBoolean("isChildModeActive", true).apply()
                            val intent = Intent(this@MainActivity2, KidsLauncher::class.java)
                            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                            startActivity(intent)
                        }
                    } else {
                        Toast.makeText(this@MainActivity2, "لم يتم التحقق: ${response.message}", Toast.LENGTH_LONG).show()
                        editor.putBoolean("isChildModeActive", false).apply()
                        switchChildActive.isChecked = false
                    }
                }
            } catch (e: Exception) {
                launch(Dispatchers.Main) {
                    Toast.makeText(this@MainActivity2, "خطأ في الاتصال بالخادم: ${e.message}", Toast.LENGTH_LONG).show()
                    Log.e("MainActivity2", "Network error: ${e.message}", e)
                    val prefs = getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
                    prefs.edit().putBoolean("isChildModeActive", false).apply()
                    switchChildActive.isChecked = false
                }
            } finally {
                stopCamera()
                if (file.exists()) {
                    file.delete()
                    Log.d("MainActivity2", "Temporary file deleted: ${file.absolutePath}")
                }
            }
        }
    }

    private fun stopCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            val cameraProvider: ProcessCameraProvider = cameraProviderFuture.get()
            cameraProvider.unbindAll()
            isCameraActive = false
        }, ContextCompat.getMainExecutor(this))
    }

    override fun onDestroy() {
        super.onDestroy()
        cameraExecutor.shutdown()
    }

    companion object {
        // يمكنك إضافة ثوابت أخرى هنا إذا لزم الأمر
    }
}