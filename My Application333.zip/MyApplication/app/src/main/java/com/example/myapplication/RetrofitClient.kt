package com.example.myapplication

import okhttp3.OkHttpClient // **** استورد هذا ****
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit // **** استورد هذا ****

object RetrofitClient {
    // تم إضافة "/" في نهاية الـ BASE_URL
    private const val BASE_URL = "http://168.231.108.230:5000/" //

    // **** قم بإنشاء OkHttpClient لتعيين مهل الاتصال ****
    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS) // زيادة مهلة الاتصال إلى 30 ثانية
        .readTimeout(60, TimeUnit.SECONDS)    // زيادة مهلة القراءة إلى 60 ثانية
        .writeTimeout(60, TimeUnit.SECONDS)   // زيادة مهلة الكتابة إلى 60 ثانية
        .build()

    val apiService: ApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .client(okHttpClient) // **** أضف الـ OkHttpClient إلى Retrofit Builder ****
            .build()
            .create(ApiService::class.java)
    }
}