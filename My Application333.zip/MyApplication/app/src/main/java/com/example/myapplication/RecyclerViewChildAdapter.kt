package com.example.myapplication

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.cardview.widget.CardView
import android.widget.Button
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView

interface OnItemDeleteListener {
    fun onItemDelete(position: Int)
}

interface OnItemEditListener {
    fun onItemEdit(child: Child, position: Int)
}

class RecyclerViewChildAdapter(
    private val activity: MainActivity2,
    private val childList: MutableList<Child>,
    private val deleteListener: OnItemDeleteListener,
    private val editListener: OnItemEditListener? = null
) : RecyclerView.Adapter<RecyclerViewChildAdapter.ChildViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ChildViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.children_list_item, parent, false)
        return ChildViewHolder(view)
    }

    override fun onBindViewHolder(holder: ChildViewHolder, position: Int) {
        val child = childList[position]

        holder.bind(child)

        holder.ivchildimg.setOnClickListener {
            deleteListener.onItemDelete(holder.adapterPosition)
        }




        holder.cardView.setOnClickListener {
            showChildToast(child.title)
        }
    }

    override fun getItemCount(): Int = childList.size

    //private fun navigateToAppsLimitation(child: Child) {
      //  Intent(activity, Appslimitation::class.java).apply {
        //    putExtra("CHILD_NAME", child.title)
          //  putExtra("CHILD_IMAGE", child.image)
            //activity.startActivity(this)
        //}
    //}

    private fun showChildToast(name: String) {
        Toast.makeText(activity, name, Toast.LENGTH_LONG).show()
    }

    fun updateChild(position: Int, updatedChild: Child) {
        childList[position] = updatedChild
        notifyItemChanged(position)
    }

    fun addChild(newChild: Child) {
        childList.add(newChild)
        notifyItemInserted(childList.size - 1)
    }

    fun deleteItem(position: Int) {
        childList.removeAt(position)
        notifyItemRemoved(position)
    }

    class ChildViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvchildtitle: TextView = itemView.findViewById(R.id.tvchildtitle)
        val ivchildimg: ImageView = itemView.findViewById(R.id.ivchildimg)
        val qvchildimg: ImageView = itemView.findViewById(R.id.qvchildimg)
        val cardView: CardView = itemView.findViewById(R.id.cardView)

        fun bind(child: Child) {
            tvchildtitle.text = child.title
            qvchildimg.setImageResource(child.image)
            ivchildimg.setImageResource(R.drawable.trash)
        }
    }
}