package com.example.myapplication
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable // استيراد Drawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import android.util.Log // استيراد Log

class AppsAdapter(
    private val context: Context,
    private val appList: List<AppModel>,
    // في شاشة Apps (الوالدين)، هذه القائمة تمثل التطبيقات التي تم اختيارها.
    // في شاشة KidsLauncher (الطفل)، هذه القائمة ستكون فارغة، مما يعني عدم تطبيق تغيير اللون.
    private val selectedApps: List<AppModel>,
    private val packageManager: PackageManager,
    private val onAppClick: (AppModel) -> Unit
) : RecyclerView.Adapter<AppsAdapter.AppViewHolder>() { // تغيير اسم ViewHolder

    // تغيير اسم ViewHolder
    class AppViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val appIcon: ImageView = view.findViewById(R.id.appIcon)
        val appName: TextView = view.findViewById(R.id.appName)
        val itemLayout: View = view

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AppViewHolder { // تغيير اسم ViewHolder
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_app, parent, false)
        return AppViewHolder(view) // تغيير اسم ViewHolder
    }

    override fun onBindViewHolder(holder: AppViewHolder, position: Int) { // تغيير اسم ViewHolder
        val app = appList[position]

        holder.appName.text = app.name

        try {
            val icon: Drawable = packageManager.getApplicationIcon(app.packageName) // تحديد النوع كـ Drawable
            holder.appIcon.setImageDrawable(icon)
        } catch (e: PackageManager.NameNotFoundException) {
            Log.e("AppsAdapter", "App icon not found for ${app.packageName}: ${e.message}") // استخدام Log
            holder.appIcon.setImageResource(android.R.drawable.sym_def_app_icon) // أيقونة افتراضية
        }

        holder.itemLayout.setOnClickListener {
            onAppClick(app)
        }

        // تغيير الخلفية إذا كان التطبيق محدد
        // هذا الجزء يستخدم بشكل أساسي في شاشة Apps (الوالدين) لتمييز التطبيقات المختارة.
        // في شاشة KidsLauncher (الطفل)، سيتم تمرير قائمة selectedApps فارغة، لذلك لن تتغير الخلفية.
        if (selectedApps.contains(app)) {
            holder.itemLayout.setBackgroundColor(
                ContextCompat.getColor(holder.itemView.context, R.color.teal_200)
            )
        } else {
            holder.itemLayout.setBackgroundColor(
                ContextCompat.getColor(holder.itemView.context, android.R.color.transparent)
            )
        }


    }

    override fun getItemCount(): Int = appList.size
}
