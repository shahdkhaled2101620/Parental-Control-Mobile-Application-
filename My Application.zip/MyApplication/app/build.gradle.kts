plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
}

android {
    namespace = "com.example.myapplication"
    compileSdk = 35 // حافظ على هذا إذا كنت تعمل مع أحدث SDK

    defaultConfig {
        applicationId = "com.example.myapplication"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
    kotlinOptions {
        jvmTarget = "11"
    }
}

dependencies {

    // AndroidX Core (المكتبات الأساسية)
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.androidx.activity)
    // إضافة activity-ktx لحل مشكلة 'enableEdgeToEdge' وتوفير دوال Kotlin الإضافية للـ Activity
    // تأكد من استخدام إصدار متوافق مع compileSdk الخاص بك
    implementation("androidx.activity:activity-ktx:1.9.0") // تم التحديث إلى إصدار أحدث ومتوافق
    implementation(libs.androidx.constraintlayout)

    // Material Design (واجهة المستخدم - تأكد من وجود تبعية واحدة فقط للإصدارات الحديثة)
    implementation(libs.material) // إذا كان libs.material يشير إلى إصدار حديث فهو الأفضل

    // RecyclerView (لعرض القوائم بكفاءة)
    implementation("androidx.recyclerview:recyclerview:1.3.2")

    // CardView (لعرض العناصر في بطاقات)
    implementation("androidx.cardview:cardview:1.0.0")

    // ML Kit Face Detection (لكشف الوجه)
    implementation("com.google.mlkit:face-detection:16.1.5")

    // CameraX (للتفاعل مع الكاميرا - تأكد من أن إصدارات CameraX متوافقة مع بعضها البعض)
    // ملاحظة: هذه الإصدارات قد تكون قديمة بعض الشيء لـ compileSdk 35. إذا واجهت مشاكل،
    // قد تحتاج إلى التحديث إلى إصدارات CameraX أحدث (مثل 1.3.0 أو 1.4.0-beta01).
    implementation("androidx.camera:camera-core:1.3.0")
    implementation("androidx.camera:camera-lifecycle:1.3.0")
    implementation("androidx.camera:camera-view:1.3.0")

    // OkHttp (مكتبة عميل HTTP قوية)
    // استخدام OkHttp BOM (Bill of Materials) لضمان التوافق بين مكونات OkHttp
    implementation(platform("com.squareup.okhttp3:okhttp-bom:4.12.0"))
    // لا تحدد الإصدار هنا، سيتم تحديده بواسطة BOM
    implementation("com.squareup.okhttp3:okhttp")
    implementation("com.squareup.okhttp3:logging-interceptor") // لمسجل الطلبات/الاستجابات

    // Volley (مكتبة أخرى لطلبات الشبكة - يمكنك اختيارها أو Retrofit)
    implementation("com.android.volley:volley:1.2.1")

    // Retrofit (مكتبة عميل HTTP قوية وموصى بها بشكل كبير لطلبات API)
    implementation ("com.squareup.retrofit2:retrofit:2.9.0")
    // Gson Converter (لتحويل JSON إلى كائنات Kotlin/Java والعكس)
    implementation ("com.squareup.retrofit2:converter-gson:2.9.0")

    // اختبارات الوحدة (Unit Tests)
    testImplementation(libs.junit)

    // اختبارات الأدوات (Instrumentation Tests) - لتشغيل الاختبارات على الجهاز/المحاكي
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)
    implementation ("com.google.code.gson:gson:2.10.1")

    // لإضافة OkHttp (لطلبات الشبكة)
    implementation("com.squareup.okhttp3:okhttp:4.10.0")
    // Coroutines (ضروري إذا كنت تستخدم suspend functions مع Retrofit)
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-core:1.8.0") // استخدم أحدث إصدار
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.0") // استخدم أحدث إصدار


    // لإضافة CameraX (للكاميرا)
    implementation("androidx.camera:camera-camera2:1.1.0")
    implementation("androidx.camera:camera-lifecycle:1.1.0")
    implementation("androidx.camera:camera-view:1.0.0-alpha30") // قد تحتاج إلى تحديث هذا الإصدار إلى الأحدث المتاح



}
