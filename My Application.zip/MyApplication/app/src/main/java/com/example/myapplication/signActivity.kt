package com.example.myapplication
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView // تأكد من استيراد ImageView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.android.volley.Request
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import org.json.JSONObject

class signActivity : AppCompatActivity() {
    private lateinit var nameInput: EditText
    private lateinit var emailInput: EditText
    private lateinit var passwordInput: EditText
    private lateinit var profileImagePlaceholder: ImageView // هذا الإعلان صحيح

    private var imagePath: String = "/Uploads/parent_image.jpg" // قيمة افتراضية مؤقتة

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_sign)

        // تهيئة الـ Views
        nameInput = findViewById(R.id.nameTextView)
        emailInput = findViewById(R.id.EmailTextView)
        passwordInput = findViewById(R.id.CreatepasswordTextView)

        // التصحيح هنا: قم بتهيئة profileImagePlaceholder
        profileImagePlaceholder = findViewById(R.id.imageView2) // افترضنا أن imageView2 هو الـ ImageView المقصود للتفاعل مع المستخدم

        val signupButton = findViewById<Button>(R.id.button4)

        // اختيار صورة (هنتعامل معها لاحقًا)
        profileImagePlaceholder.setOnClickListener {
            Toast.makeText(this, "Image selection will be implemented later", Toast.LENGTH_SHORT).show()
        }

        // لما المستخدم يضغط على Sign Up
        signupButton.setOnClickListener {
            val name = nameInput.text.toString().trim()
            val email = emailInput.text.toString().trim()
            val password = passwordInput.text.toString().trim()

            if (name.isEmpty() || email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "الرجاء ملء جميع الحقول", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // إرسال البيانات
            registerParent(email, password, name)
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    private fun registerParent(email: String, password: String, fullName: String) {
        val url = "http://168.231.108.230/ParentalCo/register_parent.php"
        val requestQueue = Volley.newRequestQueue(this)

        val jsonBody = JSONObject().apply {
            put("email", email)
            put("password", password)
            put("full_name", fullName)
            put("image_path", imagePath) // مؤقتًا، قيمة افتراضية
        }

        val jsonRequest = JsonObjectRequest(Request.Method.POST, url, jsonBody,
            { response ->
                val status = response.getString("status").trim().lowercase()
                val message = response.getString("message")
                Toast.makeText(this, message, Toast.LENGTH_LONG).show()

                if (status == "success") {
                    startActivity(Intent(this, MainActivity::class.java))
                    finish()
                }
            },
            { error ->
                Toast.makeText(this, "خطأ: ${error.message}", Toast.LENGTH_LONG).show()
            })

        requestQueue.add(jsonRequest)
    }
}