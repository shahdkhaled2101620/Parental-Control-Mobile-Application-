package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONObject
import java.io.IOException

class ForgetpasswordActivity : AppCompatActivity() {

    // Define the API URL for password reset
    private val API_URL = "http://168.231.108.230/ParentalCo/forgot_password.php"
    // Initialize OkHttpClient for network requests
    private val client = OkHttpClient()

    // Declare UI components using lateinit to initialize them in onCreate
    private lateinit var emailInput: EditText
    private lateinit var passwordInput: EditText
    private lateinit var confirmPasswordInput: EditText
    private lateinit var doneButton: Button
    private lateinit var backButton: ImageView // Renamed from btnBack for clarity

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge() // Enable edge-to-edge display
        setContentView(R.layout.activity_forgetpassword) // Set the layout for this activity

        // Apply window insets to adjust padding for system bars (status bar, navigation bar)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Initialize UI components by finding their IDs in the layout
        backButton = findViewById(R.id.backButton)
        doneButton = findViewById(R.id.doneButton)
        emailInput = findViewById(R.id.emailInput) // Assuming 'emailInput' is the ID for the email EditText in your XML
        passwordInput = findViewById(R.id.passwordInput)
        confirmPasswordInput = findViewById(R.id.confirmPasswordInput)

        // Set an OnClickListener for the back button
        backButton.setOnClickListener {
            // Create an Intent to navigate to MainActivity (login page)
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent) // Start the MainActivity
            finish() // Close the current ForgetpasswordActivity
        }

        // Set an OnClickListener for the done button
        doneButton.setOnClickListener {
            // Get the text from input fields and trim any leading/trailing whitespace
            val email = emailInput.text.toString().trim()
            val newPassword = passwordInput.text.toString().trim()
            val confirmPassword = confirmPasswordInput.text.toString().trim()

            // Perform basic validation: check if any field is empty
            if (email.isEmpty() || newPassword.isEmpty() || confirmPassword.isEmpty()) {
                Toast.makeText(this, "من فضلك املأ كل الحقول", Toast.LENGTH_SHORT).show()
                return@setOnClickListener // Stop execution if fields are empty
            }

            // Validate if the new password and confirm password match
            if (newPassword != confirmPassword) {
                Toast.makeText(this, "كلمات المرور لا تتطابق", Toast.LENGTH_SHORT).show()
                return@setOnClickListener // Stop execution if passwords don't match
            }

            // Call the method to reset the password via API
            resetPassword(email, newPassword)
        }
    }

    /**
     * Sends a request to the server to reset the user's password.
     * @param email The user's email address.
     * @param newPassword The new password to set.
     */
    private fun resetPassword(email: String, newPassword: String) {
        // Create a JSON object for the request body
        val jsonBody = JSONObject().apply {
            put("email", email) // Put the email into the JSON object
            put("new_password", newPassword) // Put the new password into the JSON object
        }

        // Define the media type for JSON requests
        val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()
        // Create the request body from the JSON object
        val body = jsonBody.toString().toRequestBody(JSON_MEDIA_TYPE)

        // Build the HTTP POST request
        val request = Request.Builder()
            .url(API_URL) // Set the API URL
            .post(body) // Set the request method to POST with the created body
            .build() // Build the request

        // Execute the request asynchronously
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                // This method is called when the network request fails (e.g., no internet, host unreachable)
                e.printStackTrace() // Print stack trace for debugging
                // Show a toast message on the UI thread
                runOnUiThread {
                    Toast.makeText(this@ForgetpasswordActivity, "خطأ في الشبكة: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }

            override fun onResponse(call: Call, response: Response) {
                // This method is called when the server responds, regardless of success or failure (e.g., 200 OK, 404 Not Found)
                response.body?.string()?.let { responseData ->
                    runOnUiThread {
                        try {
                            // Parse the JSON response from the server
                            // Assuming the API returns a JSON object like {"status": "success", "message": "Password updated successfully"}
                            val jsonResponse = JSONObject(responseData)
                            val status = jsonResponse.optString("status") // Get the "status" field, default empty string if not found
                            val message = jsonResponse.optString("message", "استجابة غير معروفة من الخادم") // Get the "message" field, with a default message

                            if (response.isSuccessful && status == "success") {
                                // If the response was successful (HTTP 200-299) and the API indicated success
                                Toast.makeText(this@ForgetpasswordActivity, message, Toast.LENGTH_LONG).show()
                                // Navigate back to MainActivity (login page)
                                val intent = Intent(this@ForgetpasswordActivity, MainActivity::class.java)
                                startActivity(intent) // Start the login activity
                                finish() // Close the current activity
                            } else {
                                // If the API returned an error status or HTTP error code
                                val errorMessage = if (response.isSuccessful) {
                                    // API returned an error status in JSON body
                                    "خطأ: $message"
                                } else {
                                    // HTTP error code
                                    "خطأ من الخادم: ${response.code} ${response.message}"
                                }
                                Toast.makeText(this@ForgetpasswordActivity, errorMessage, Toast.LENGTH_LONG).show()
                            }
                        } catch (e: Exception) {
                            e.printStackTrace() // Print stack trace if JSON parsing fails or other unexpected error
                            Toast.makeText(this@ForgetpasswordActivity, "فشل تحليل الاستجابة من الخادم: ${e.message}", Toast.LENGTH_LONG).show()
                        }
                    }
                } ?: run {
                    // Handle cases where response body is null
                    runOnUiThread {
                        Toast.makeText(this@ForgetpasswordActivity, "استجابة فارغة من الخادم", Toast.LENGTH_LONG).show()
                    }
                }
            }
        })
    }
}