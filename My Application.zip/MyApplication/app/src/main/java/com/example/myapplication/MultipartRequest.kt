package com.example.myapplication
import com.android.volley.AuthFailureError
import com.android.volley.NetworkResponse
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.HttpHeaderParser
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.IOException
import java.util.HashMap

/**
 * فئة طلب Volley مخصصة لرفع الملفات باستخدام multipart/form-data.
 * This custom Volley request class handles file uploads using multipart/form-data.
 *
 * @param method طريقة الطلب (POST).
 * @param url عنوان URL لرفع الملف.
 * @param file الملف الذي سيتم رفعه.
 * @param fileFieldName اسم الحقل للملف في الطلب (عادةً "image" كما في سكريبت PHP).
 * @param fileName اسم الملف الذي سيتم إرساله إلى الخادم.
 * @param mimeType نوع MIME للملف (مثل "image/jpeg").
 * @param textParams المعلمات النصية الإضافية (مثل "parent_id").
 * @param listener مستمع للاستجابة الناجحة من الخادم.
 * @param errorListener مستمع للاستجابة الخطأ من الخادم.
 */
class MultipartRequest(
    method: Int,
    url: String,
    private val file: File,
    private val fileFieldName: String,
    private val fileName: String,
    private val mimeType: String,
    private val textParams: Map<String, String>,
    listener: Response.Listener<String>,
    errorListener: Response.ErrorListener
) : Request<String>(method, url, errorListener) {

    private val responseListener: Response.Listener<String> = listener
    private val boundary: String = "----${System.currentTimeMillis()}" // إنشاء حدود فريدة

    // تعيين نوع المحتوى في الرأس ليشمل الحدود
    @Throws(AuthFailureError::class)
    override fun getHeaders(): MutableMap<String, String> =
        super.getHeaders().toMutableMap().apply {
            put("Content-Type", "multipart/form-data;boundary=$boundary")
        }

    // بناء جسم الطلب (البيانات التي سيتم إرسالها إلى الخادم)
    @Throws(AuthFailureError::class)
    override fun getBody(): ByteArray {
        val bos = ByteArrayOutputStream() // تيار لتجميع بيانات الجسم
        try {
            // كتابة جزء الملف
            bos.write("--$boundary\r\n".toByteArray()) // بداية الجزء بحدود
            // عنوان التصرف في المحتوى يحدد اسم الحقل واسم الملف
            bos.write("Content-Disposition: form-data; name=\"$fileFieldName\"; filename=\"$fileName\"\r\n".toByteArray())
            bos.write("Content-Type: $mimeType\r\n\r\n".toByteArray()) // نوع المحتوى للملف

            // قراءة محتوى الملف وكتابته في تيار الإخراج
            val fileInputStream = FileInputStream(file)
            fileInputStream.copyTo(bos) // نسخ بايتات الملف إلى تيار الإخراج
            fileInputStream.close() // إغلاق تيار إدخال الملف
            bos.write("\r\n".toByteArray()) // إضافة سطر جديد بعد بيانات الملف

            // كتابة المعلمات النصية (مثل parent_id)
            for ((key, value) in textParams) {
                bos.write("--$boundary\r\n".toByteArray()) // بداية جزء جديد بحدود
                bos.write("Content-Disposition: form-data; name=\"$key\"\r\n\r\n".toByteArray()) // اسم الحقل
                bos.write(value.toByteArray()) // قيمة المعلمة
                bos.write("\r\n".toByteArray()) // إضافة سطر جديد بعد قيمة المعلمة
            }
            bos.write("--$boundary--\r\n".toByteArray()) // نهاية الطلب بحدود الإغلاق

        } catch (e: IOException) {
            e.printStackTrace() // طباعة تتبع الخطأ في حالة حدوث استثناء I/O
        }
        return bos.toByteArray() // إرجاع جسم الطلب كصفيف من البايتات
    }

    // تحليل استجابة الشبكة من الخادم
    override fun parseNetworkResponse(response: NetworkResponse): Response<String> {
        return try {
            // تحويل بايتات الاستجابة إلى سلسلة نصية باستخدام UTF-8
            val jsonString = String(
                response.data,
                Charsets.UTF_8 // أو تحديد مجموعة الأحرف الصحيحة من رؤوس الاستجابة
            )
            // إرجاع استجابة ناجحة مع البيانات المحللة ورؤوس التخزين المؤقت
            Response.success(jsonString, HttpHeaderParser.parseCacheHeaders(response))
        } catch (e: Exception) {
            // في حالة حدوث خطأ في التحليل، إرجاع خطأ تحليل
            Response.error(com.android.volley.ParseError(e))
        }
    }

    // تسليم الاستجابة الناجحة إلى المستمع
    override fun deliverResponse(response: String) {
        responseListener.onResponse(response)
    }

    // دالة getParams غير مطلوبة لـ multipart/form-data لأن المعلمات يتم تضمينها في getBody()
    // ولكن يجب تجاوزها إذا كان superclass يتطلبها، وإرجاع خريطة فارغة
    @Throws(AuthFailureError::class)
    override fun getParams(): MutableMap<String, String>? {
        return super.getParams() // سيكتشف Volley أنها فارغة إذا لم يتم تجاوزها بشكل صريح لـ multipart
    }
}

