// File: com/example/myapplication/data/AppCreationRequest.kt (أو في أي حزمة تختارها لنماذج البيانات)
package com.example.myapplication.data

import com.google.gson.annotations.SerializedName

data class AppCreationRequest(
    @SerializedName("app_name") val appName: String,
    @SerializedName("app_status") val appStatus: Int,
    @SerializedName("parent_id") val parentId: Int,
    @SerializedName("limit_time") val limitTime: String // يفضل استخدام String إذا كان التنسيق "HH:mm:ss"
)