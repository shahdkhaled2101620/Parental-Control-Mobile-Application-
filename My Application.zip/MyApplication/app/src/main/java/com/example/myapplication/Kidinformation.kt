package com.example.myapplication

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.activity.result.contract.ActivityResultContracts
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

class Kidinformation : AppCompatActivity() {

    private lateinit var kidNameEditText: EditText
    private lateinit var addChildButton: Button
    private lateinit var btnBack: ImageView
    private lateinit var addImageButton: ImageView // زر + لاختيار صورة الطفل
    private lateinit var childImageView: ImageView  // لعرض معاينة الصورة المختارة
    private val client = OkHttpClient()
    private var selectedImageUri: Uri? = null
    private var uploadedChildId: Int = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_kidinformation)

        kidNameEditText = findViewById(R.id.nameTextView)
        addChildButton = findViewById(R.id.button15)
        btnBack = findViewById(R.id.imageView11)
        addImageButton = findViewById(R.id.imageView13)
        childImageView = findViewById(R.id.imageView12)

        addChildButton.setOnClickListener {
            addChild()
        }

        btnBack.setOnClickListener {
            startActivity(Intent(this, add_child1::class.java))
            finish()
        }

        addImageButton.setOnClickListener {
            openGallery()
        }

        // 🔁 تعديل زر Select Apps ليقوم فقط بالتنقل للصفحة التالية
        val selectAppsButton: Button = findViewById(R.id.button6)
        selectAppsButton.setOnClickListener {
            val intent = Intent(this, Apps::class.java)
            startActivity(intent)
        }
    }

    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let {
            childImageView.setImageURI(it)
            selectedImageUri = it
            Toast.makeText(this, "تم اختيار الصورة بنجاح!", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openGallery() {
        pickImage.launch("image/*")
    }

    private fun addChild() {
        val fullName = kidNameEditText.text.toString().trim()
        if (fullName.isEmpty()) {
            Toast.makeText(this, "يرجى إدخال اسم الطفل", Toast.LENGTH_SHORT).show()
            return
        }

        val prefs = getSharedPreferences("user_prefs", Context.MODE_PRIVATE)
        val parentId = prefs.getInt("parent_id", -1)
        if (parentId == -1) {
            Toast.makeText(this, "لم يتم العثور على parent_id", Toast.LENGTH_LONG).show()
            return
        }

        val url = "http://168.231.108.230/ParentalCo/add_child.php"
        val jsonBody = JSONObject().apply {
            put("full_name", fullName)
            put("image_path", "/Uploads/child_image.jpg") // صورة افتراضية
            put("parent_id", parentId)
        }

        val JSON = "application/json; charset=utf-8".toMediaTypeOrNull()
        val requestBody = jsonBody.toString().toRequestBody(JSON)
        val request = Request.Builder()
            .url(url)
            .post(requestBody)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    Toast.makeText(this@Kidinformation, "فشل الاتصال: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val responseBody = response.body?.string()
                runOnUiThread {
                    if (response.isSuccessful && responseBody != null) {
                        try {
                            val jsonResponse = JSONObject(responseBody)
                            val status = jsonResponse.optString("status")
                            val message = jsonResponse.optString("message")
                            if (status == "success") {
                                Toast.makeText(this@Kidinformation, "تم إضافة الطفل بنجاح", Toast.LENGTH_LONG).show()
                                getChildId(parentId, fullName)
                            } else {
                                Toast.makeText(this@Kidinformation, "فشل: $message", Toast.LENGTH_LONG).show()
                            }
                        } catch (e: Exception) {
                            Toast.makeText(this@Kidinformation, "خطأ في تحليل الرد: ${e.message}", Toast.LENGTH_LONG).show()
                        }
                    } else {
                        Toast.makeText(this@Kidinformation, "فشل: ${response.code}\n$responseBody", Toast.LENGTH_LONG).show()
                    }
                }
            }
        })
    }

    private fun getChildId(parentId: Int, childName: String) {
        val url = "http://168.231.108.230/ParentalCo/get_child_id.php"
        val jsonBody = JSONObject().apply {
            put("parent_id", parentId)
            put("child_name", childName)
        }

        val JSON = "application/json; charset=utf-8".toMediaTypeOrNull()
        val requestBody = jsonBody.toString().toRequestBody(JSON)
        val request = Request.Builder()
            .url(url)
            .post(requestBody)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    Toast.makeText(this@Kidinformation, "فشل جلب child_id: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val responseBody = response.body?.string()
                runOnUiThread {
                    if (response.isSuccessful && responseBody != null) {
                        try {
                            val jsonResponse = JSONObject(responseBody)
                            val childId = jsonResponse.optInt("child_id", -1)
                            if (childId != -1) {
                                uploadedChildId = childId
                                val sharedPrefs = getSharedPreferences("child_add_response", Context.MODE_PRIVATE)
                                val existingListString = sharedPrefs.getString("children_list", "[]")
                                val existingList = JSONArray(existingListString)
                                val newChild = JSONObject().apply {
                                    put("full_name", childName)
                                    put("child_id", childId)
                                }
                                existingList.put(newChild)
                                sharedPrefs.edit().putString("children_list", existingList.toString()).apply()
                                Toast.makeText(this@Kidinformation, "تم حفظ الطفل ومعرفه بنجاح", Toast.LENGTH_LONG).show()
                                if (selectedImageUri != null) {
                                    uploadChildImage(childId, selectedImageUri!!)
                                } else {
                                    Toast.makeText(this@Kidinformation, "لم يتم اختيار صورة لرفعها. سيتم استخدام الصورة الافتراضية.", Toast.LENGTH_SHORT).show()
                                }
                            } else {
                                Toast.makeText(this@Kidinformation, "لم يتم العثور على معرف الطفل", Toast.LENGTH_LONG).show()
                            }
                        } catch (e: Exception) {
                            Toast.makeText(this@Kidinformation, "خطأ في تحليل رد معرف الطفل: ${e.message}", Toast.LENGTH_LONG).show()
                        }
                    } else {
                        Toast.makeText(this@Kidinformation, "فشل في جلب معرف الطفل: ${response.code}", Toast.LENGTH_LONG).show()
                    }
                }
            }
        })
    }

    private fun uploadChildImage(childId: Int, imageUri: Uri) {
        val url = "http://168.231.108.230/ParentalCo/upload_child_image.php"
        val imageFile = uriToFile(imageUri)
        if (imageFile == null || !imageFile.exists()) {
            runOnUiThread {
                Toast.makeText(this, "فشل في قراءة ملف الصورة", Toast.LENGTH_SHORT).show()
            }
            return
        }

        val requestBody = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart("image", imageFile.name, imageFile.asRequestBody("image/jpeg".toMediaTypeOrNull()))
            .addFormDataPart("child_id", childId.toString())
            .build()

        val request = Request.Builder()
            .url(url)
            .post(requestBody)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    Toast.makeText(this@Kidinformation, "فشل رفع الصورة: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val responseBody = response.body?.string()
                runOnUiThread {
                    if (response.isSuccessful) {
                        Toast.makeText(this@Kidinformation, "تم رفع صورة الطفل بنجاح", Toast.LENGTH_LONG).show()
                    } else {
                        Toast.makeText(this@Kidinformation, "فشل رفع الصورة: رمز ${response.code}\n$responseBody", Toast.LENGTH_LONG).show()
                    }
                }
            }
        })
    }

    private fun uriToFile(uri: Uri): File? {
        val contentResolver = applicationContext.contentResolver
        val fileName = "child_image_temp_${System.currentTimeMillis()}.jpg"
        val file = File(cacheDir, fileName)
        return try {
            contentResolver.openInputStream(uri)?.use { inputStream ->
                FileOutputStream(file).use { outputStream ->
                    inputStream.copyTo(outputStream)
                }
            }
            file
        } catch (e: IOException) {
            e.printStackTrace()
            runOnUiThread {
                Toast.makeText(this, "خطأ في إنشاء ملف مؤقت للصورة: ${e.message}", Toast.LENGTH_SHORT).show()
            }
            null
        }
    }
}