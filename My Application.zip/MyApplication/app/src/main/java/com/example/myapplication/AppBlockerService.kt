package com.example.myapplication

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.accessibilityservice.AccessibilityServiceInfo
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import android.view.WindowManager
import android.view.LayoutInflater
import android.os.Handler
import android.os.Looper
import android.content.IntentFilter // جديد: لتلقي إشعارات الشاشة
import android.content.BroadcastReceiver // جديد: لتلقي إشعارات الشاشة
import android.content.res.Configuration // جديد: لتلقي إشعارات تغيير التكوين

class AppBlockerService : AccessibilityService() {

    private lateinit var selectedPackages: Set<String>
    private var isPasswordDialogShowing = false
    private var lastBlockedPackage: String? = null

    private var currentlyUnlockedPackage: String? = null

    private lateinit var systemAndLauncherPackages: Set<String>

    private var isChildModeActive: Boolean = false
    private val handler = Handler(Looper.getMainLooper())

    // **** متغيرات جديدة لتتبع الوقت اليومي ****
    private var dailyTimeLimitMillis: Long = 0L // الحد الأقصى للوقت اليومي بالمللي ثانية
    private var timeUsedMillis: Long = 0L       // الوقت المستغل فعليًا اليوم بالمللي ثانية
    private var lastTimeRecorded: Long = 0L     // آخر مرة تم تسجيل الوقت فيها (بالمللي ثانية منذ الإقلاع)
    private var isTrackingTime: Boolean = false // هل نحن نقوم بتتبع الوقت حاليًا؟
    private var dailyTimeLimitExceeded: Boolean = false // هل تم تجاوز الوقت المسموح به؟

    // Receiver لمراقبة حالة الشاشة
    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                Intent.ACTION_SCREEN_ON -> {
                    Log.d("AppBlockerService", "SCREEN ON. Resuming time tracking if child mode active.")
                    if (isChildModeActive && !dailyTimeLimitExceeded) {
                        startTrackingTime()
                    }
                }
                Intent.ACTION_SCREEN_OFF -> {
                    Log.d("AppBlockerService", "SCREEN OFF. Pausing time tracking.")
                    pauseTrackingTime()
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        systemAndLauncherPackages = setOf(
            this.packageName,
            "com.android.systemui",
            "com.android.launcher",
            "com.google.android.apps.nexuslauncher",
            "com.sec.android.app.launcher",
            "com.miui.home",
            "com.huawei.android.launcher",
            "com.android.settings",
            "com.google.android.inputmethod.latin",
            "android",
            "com.android.vending",
            "com.google.android.gms",
            "com.google.android.permissioncontroller",
            "com.android.packageinstaller",
            "com.google.android.apps.wellbeing",
            "com.samsung.android.app.galaxyfinder",
            "com.samsung.android.app.taskedge",
            "com.samsung.android.app.genie",
            "com.android.chrome",
            "com.android.incallui",
            "com.google.android.dialer",
            "com.samsung.android.app.contacts",
            "com.android.contacts",
            "com.samsung.android.messaging",
            "com.google.android.apps.messaging",
            "com.samsung.android.calendar",
            "com.google.android.calendar",
            "com.samsung.android.app.filter",
            "com.android.documentsui",
            "com.android.providers.media",
            "com.android.camera",
            "com.samsung.android.app.camera",
            "com.google.android.googlequicksearchbox",
            "com.google.android.launcher",
            "com.android.launcher3",
            "com.oneplus.android.launcher",
            "com.oppo.launcher",
            "com.vivo.launcher",
            "com.htc.launcher",
            "com.lge.launcher",
            "com.sonymobile.home",
            "com.samsung.android.app.lockscreen",
            "com.sec.android.app.sbrowser",
            "com.samsung.android.honeyboard",
            "com.google.android.inputmethod.latin.debug",
            "com.touchtype.swiftkey",
            "com.nuance.swype.dtc",
            "com.sec.android.inputmethod",
            "com.google.android.apps.assistant",
            "com.google.android.googlequicksearchbox"
        )
        loadSettings() // حمل الإعدادات أول ما الخدمة تبدأ
        registerScreenReceiver() // سجل الـ receiver عشان يراقب الشاشة

        // **** بدء تتبع الوقت إذا كان وضع الطفل نشطًا من البداية ****
        if (isChildModeActive && !dailyTimeLimitExceeded) {
            startTrackingTime()
        }
        Log.d("AppBlockerService", "Service created. Child Mode Active: $isChildModeActive, Time Used: ${timeUsedMillis}, Limit: ${dailyTimeLimitMillis}")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return

        loadSettings() // حمل الإعدادات في كل حدث عشان نضمن أحدث حالة لـ isChildModeActive والوقت.

        // لو وضع الطفل مش نشط، أو الوقت اليومي خلص، مفيش حاجة هتتحظر
        if (!isChildModeActive) {
            Log.d("AppBlockerService", "Child mode is not active. Skipping app blocking.")
            pauseTrackingTime() // أوقف تتبع الوقت لو وضع الطفل مش فعال
            return
        }

        // **** لو الوقت اليومي خلص، احظر كل حاجة ما عدا تطبيقنا ونظام التشغيل ****
        if (dailyTimeLimitExceeded) {
            val packageName = event.packageName?.toString()
            if (packageName != null && !systemAndLauncherPackages.contains(packageName) && packageName != this.packageName) {
                Log.w("AppBlockerService", "Daily time limit exceeded! Blocking app: $packageName")
                // ممكن هنا نعرض شاشة خاصة "الوقت انتهى" بدلاً من KidsLauncher
                // For now, redirect to KidsLauncher or a dedicated "Time's Up" screen if available
                returnToKidsLauncher() // أو افتح شاشة "الوقت انتهى"
            }
            return // لا تعالج أحداث أخرى إذا انتهى الوقت
        }

        if (isPasswordDialogShowing) {
            Log.d("AppBlockerService", "Password dialog is showing. Skipping event processing.")
            return
        }

        // ركز على أحداث تغيير حالة النافذة (لما يظهر تطبيق جديد في المقدمة)
        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            val packageName = event.packageName?.toString()
            Log.d("AppBlockerService", "Window state changed to: $packageName")

            if (packageName != null && selectedPackages.isNotEmpty()) {

                // 1. لو الحزمة الحالية هي حزمة نظام/لانشر/تطبيقنا، تجاهلها.
                if (systemAndLauncherPackages.contains(packageName)) {
                    Log.d("AppBlockerService", "Ignoring system/launcher/self package: $packageName")
                    lastBlockedPackage = null
                    return
                }

                // 2. لو الحزمة الحالية هي التطبيق اللي اتفتح مؤقتًا بكلمة السر، اسمح بيه.
                if (packageName == currentlyUnlockedPackage) {
                    Log.d("AppBlockerService", "Allowing currently unlocked app (session): $packageName")
                    lastBlockedPackage = null
                    return
                }

                // 3. لو الحزمة الحالية مسموح بيها صراحةً من ولي الأمر، اسمح بيها.
                if (selectedPackages.contains(packageName)) {
                    Log.d("AppBlockerService", "Allowing parent-selected app: $packageName")
                    lastBlockedPackage = null
                    currentlyUnlockedPackage = null
                    return
                }

                // *** الخطوة 4: لو وصلنا لهنا، يبقى ده تطبيق غير مسموح بيه ومحظور. ***
                Log.d("AppBlockerService", "Blocking unselected app: $packageName")

                currentlyUnlockedPackage = null

                if (!isPasswordDialogShowing || lastBlockedPackage != packageName) {
                    lastBlockedPackage = packageName
                    showPasswordDialog(packageName)
                } else {
                    Log.d("AppBlockerService", "Password dialog already showing for or package already blocked: $packageName. Redirecting to KidsLauncher.")
                    returnToKidsLauncher()
                }
            }
        }
    }

    override fun onInterrupt() {
        Log.d("AppBlockerService", "Accessibility service interrupted.")
        isPasswordDialogShowing = false
        lastBlockedPackage = null
        currentlyUnlockedPackage = null
        pauseTrackingTime() // أوقف تتبع الوقت عند مقاطعة الخدمة
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        val info = AccessibilityServiceInfo()
        info.eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
        info.feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
        info.flags = AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS or
                AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS or
                AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
        info.notificationTimeout = 100
        this.serviceInfo = info
        Log.d("AppBlockerService", "Accessibility service connected.")
        loadSettings() // تأكد من تحميل الإعدادات فور اتصال الخدمة
        if (isChildModeActive && !dailyTimeLimitExceeded) {
            startTrackingTime() // استأنف تتبع الوقت لو وضع الطفل نشط
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        pauseTrackingTime() // أوقف تتبع الوقت عند تدمير الخدمة
        unregisterReceiver(screenReceiver) // إلغاء تسجيل الـ receiver
        Log.d("AppBlockerService", "Accessibility service destroyed.")
    }

    private fun showPasswordDialog(blockedPackage: String) {
        if (isPasswordDialogShowing) return

        isPasswordDialogShowing = true

        val dialogView = LayoutInflater.from(this).inflate(R.layout.custom_password_dialog, null)

        val builder = AlertDialog.Builder(this)
            .setView(dialogView)
            .setCancelable(false)

        val dialog = builder.create()

        val passwordInput = dialogView.findViewById<EditText>(R.id.passwordInput)
        val confirmButton = dialogView.findViewById<Button>(R.id.confirmButton)
        val cancelButton = dialogView.findViewById<Button>(R.id.cancelButton)

        confirmButton.setOnClickListener {
            val enteredPassword = passwordInput.text.toString()
            val savedPassword = getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
                .getString("parent_password", null)

            if (enteredPassword == savedPassword) {
                Toast.makeText(this, "كلمة المرور صحيحة. يمكنك استخدام التطبيق.", Toast.LENGTH_SHORT).show()
                try {
                    currentlyUnlockedPackage = blockedPackage
                    val launchIntent = packageManager.getLaunchIntentForPackage(blockedPackage)
                    launchIntent?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(launchIntent)
                } catch (e: Exception) {
                    Log.e("AppBlockerService", "Failed to launch app: $blockedPackage", e)
                    Toast.makeText(this, "تعذر فتح التطبيق.", Toast.LENGTH_SHORT).show()
                    returnToKidsLauncher()
                }
            } else {
                Toast.makeText(this, "كلمة المرور غير صحيحة. لا يمكن فتح التطبيق.", Toast.LENGTH_SHORT).show()
                returnToKidsLauncher()
            }
            dialog.dismiss()
            isPasswordDialogShowing = false
            handler.postDelayed({
                returnToKidsLauncher()
            }, 100)
        }

        cancelButton.setOnClickListener {
            Toast.makeText(this, "تم إلغاء العملية.", Toast.LENGTH_SHORT).show()
            returnToKidsLauncher()
            dialog.dismiss()
            isPasswordDialogShowing = false
            handler.postDelayed({
                returnToKidsLauncher()
            }, 100)
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            dialog.window?.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY)
        } else {
            @Suppress("DEPRECATION")
            dialog.window?.setType(WindowManager.LayoutParams.TYPE_SYSTEM_ALERT)
        }
        dialog.show()
    }

    // **** دالة موحدة لتحميل الإعدادات (التطبيقات المختارة، حالة وضع الطفل، الوقت اليومي) ****
    private fun loadSettings() {
        val prefs = getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
        val selectedPackagesString = prefs.getString("selected_packages_set", null)
        selectedPackages = selectedPackagesString?.split(",")?.toSet() ?: emptySet()
        isChildModeActive = prefs.getBoolean("is_child_mode_active", false)

        // تحميل الوقت اليومي
        dailyTimeLimitMillis = prefs.getLong("daily_time_limit_millis", 0L)
        // تحميل الوقت المستغل اليوم (يجب أن يتم تصفيره كل يوم جديد)
        timeUsedMillis = prefs.getLong("time_used_today", 0L)

        // **** منطق تصفير الوقت اليومي ****
        val lastResetDay = prefs.getInt("last_reset_day", -1)
        val currentDay = System.currentTimeMillis() / (1000 * 60 * 60 * 24) // عدد الأيام منذ epoch
        if (currentDay != lastResetDay.toLong()) {
            // يوم جديد، صفر الوقت المستغل
            timeUsedMillis = 0L
            prefs.edit().putLong("time_used_today", 0L).apply()
            prefs.edit().putInt("last_reset_day", currentDay.toInt()).apply()
            dailyTimeLimitExceeded = false // إعادة تعيين حالة التجاوز لليوم الجديد
            Log.d("AppBlockerService", "New day detected. Time used reset to 0.")
        }
        // تحديث حالة تجاوز الوقت
        dailyTimeLimitExceeded = timeUsedMillis >= dailyTimeLimitMillis && dailyTimeLimitMillis > 0

        Log.d("AppBlockerService", "Settings loaded. Child Mode Active: $isChildModeActive, Daily Limit: ${dailyTimeLimitMillis / 1000 / 60} min, Time Used: ${timeUsedMillis / 1000 / 60} min, Limit Exceeded: $dailyTimeLimitExceeded")
    }

    private fun returnToKidsLauncher() {
        val intent = Intent(this, KidsLauncher::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        startActivity(intent)
    }

    // **** دوال جديدة لتتبع الوقت ****

    // يبدأ مؤقت تتبع الوقت
    private fun startTrackingTime() {
        if (!isTrackingTime && isChildModeActive && !dailyTimeLimitExceeded) {
            lastTimeRecorded = System.nanoTime() // استخدم nanoTime لدقة أعلى للوقت المستغرق
            handler.post(timeTrackingRunnable)
            isTrackingTime = true
            Log.d("AppBlockerService", "Started time tracking.")
        }
    }

    // يوقف مؤقت تتبع الوقت ويحفظ الوقت المستغل
    private fun pauseTrackingTime() {
        if (isTrackingTime) {
            handler.removeCallbacks(timeTrackingRunnable)
            isTrackingTime = false
            // احسب الوقت المستغل منذ آخر تسجيل
            val elapsedTime = (System.nanoTime() - lastTimeRecorded) / 1_000_000 // بالمللي ثانية
            timeUsedMillis += elapsedTime
            val prefs = getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
            prefs.edit().putLong("time_used_today", timeUsedMillis).apply()
            Log.d("AppBlockerService", "Paused time tracking. Added ${elapsedTime}ms. Total used: ${timeUsedMillis}ms")

            // تحقق فورًا إذا كان الوقت قد انتهى
            if (dailyTimeLimitMillis > 0 && timeUsedMillis >= dailyTimeLimitMillis) {
                dailyTimeLimitExceeded = true
                Log.w("AppBlockerService", "Daily time limit exceeded!")
                returnToKidsLauncher() // أعد توجيه المستخدم مباشرة
            }
        }
    }

    // الـ Runnable اللي بيشتغل كل فترة عشان يحدث الوقت المستغل
    private val timeTrackingRunnable = object : Runnable {
        override fun run() {
            if (isTrackingTime && isChildModeActive && !dailyTimeLimitExceeded) {
                val currentTime = System.nanoTime()
                val elapsedTime = (currentTime - lastTimeRecorded) / 1_000_000 // بالمللي ثانية
                timeUsedMillis += elapsedTime
                lastTimeRecorded = currentTime

                val prefs = getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
                prefs.edit().putLong("time_used_today", timeUsedMillis).apply()

                Log.d("AppBlockerService", "Time updated. Total used: ${timeUsedMillis}ms / ${dailyTimeLimitMillis}ms")

                // تحقق إذا كان الوقت اليومي قد انتهى
                if (dailyTimeLimitMillis > 0 && timeUsedMillis >= dailyTimeLimitMillis) {
                    dailyTimeLimitExceeded = true
                    Log.w("AppBlockerService", "Daily time limit exceeded! Blocking all non-system apps.")
                    Toast.makeText(this@AppBlockerService, "انتهى الوقت اليومي لطفلك!", Toast.LENGTH_LONG).show()
                    // هنا ممكن تعمل أي حاجة إضافية لما الوقت يخلص، زي إظهار إشعار ثابت
                    pauseTrackingTime() // أوقف التتبع خلاص الوقت خلص
                    returnToKidsLauncher() // أعد توجيه المستخدم إلى KidsLauncher
                } else {
                    // كرر تشغيل الـ Runnable بعد فترة
                    handler.postDelayed(this, 1000) // كل ثانية
                }
            }
        }
    }

    // **** دوال جديدة لتتبع حالة الشاشة ****
    private fun registerScreenReceiver() {
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
        }
        registerReceiver(screenReceiver, filter)
    }

    // **** ملاحظة حول تغيير التكوين (مثل تدوير الشاشة) ****
    // هذه الدالة ليست ضرورية بشكل مباشر لتتبع الوقت ولكن قد تكون مفيدة لسلوكيات أخرى
    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        Log.d("AppBlockerService", "Configuration changed: $newConfig")
        // يمكن هنا إعادة تحميل الإعدادات أو تعديل سلوكيات أخرى بناءً على التكوين الجديد
    }
}