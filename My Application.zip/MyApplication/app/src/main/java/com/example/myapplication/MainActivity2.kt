package com.example.myapplication

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

import android.app.role.RoleManager
import android.os.Build
import android.provider.Settings
import androidx.appcompat.app.AlertDialog
import androidx.activity.OnBackPressedCallback
import android.os.Handler
import android.os.Looper
import kotlinx.coroutines.CoroutineScope // تأكد من استيراد هذا

class MainActivity2 : AppCompatActivity(), OnItemDeleteListener {
    // --- متغيرات واجهة المستخدم (UI Elements) ---
    private var recyclerView: RecyclerView? = null
    private var recyclerViewChildAdapter: RecyclerViewChildAdapter? = null
    private var childlist = mutableListOf<Child>()
    private lateinit var addCardButton: Button
    private lateinit var editProfileImageView: ImageView
    private lateinit var dailyTimeButton: Button
    private lateinit var setPasswordButton: Button
    private lateinit var passwordInputSection: LinearLayout
    private lateinit var newPasswordEditText: EditText
    private lateinit var confirmPasswordEditText: EditText
    private lateinit var savePasswordButton: Button
    private lateinit var parentNameTextView: TextView
    private lateinit var switchChildActive: SwitchCompat
    private lateinit var previewView: PreviewView

    // --- متغيرات الكاميرا والتحقق ---
    private var imageCapture: ImageCapture? = null
    private lateinit var cameraExecutor: ExecutorService
    private var isCameraActive = false // لتتبع ما إذا كانت الكاميرا تعمل حاليًا
    private var currentParentId: String = "" // لتخزين معرف الوالد الحالي
    private var isChildModeActive: Boolean = false // لتتبع ما إذا كان وضع الطفل نشطًا

    // --- متغيرات أخرى ---
    private var dailyTimeLimitMillis: Long = 0L // الحد الزمني اليومي لجميع الأطفال بالمللي ثانية

    // --- Launchers للأنشطة والمهام الخارجية ---
    private val addChildLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK) {
            val data: Intent? = result.data
            val newChildName = data?.getStringExtra("new_child_name")
            newChildName?.let {
                addNewChild(it)
                showToast("Child '$it' added successfully!")
            }
        } else if (result.resultCode == RESULT_CANCELED) {
            showToast("Adding child cancelled or failed.")
        }
    }

    private val dailyTimeLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK) {
            val data: Intent? = result.data
            dailyTimeLimitMillis = data?.getLongExtra("DAILY_TIME", 0L) ?: 0L
            val minutes = dailyTimeLimitMillis / 1000 / 60
            showToast("Daily time limit set to: $minutes minutes")
            Log.d("MainActivity2", "Daily time limit set to: $dailyTimeLimitMillis ms")

            // حفظ الحد الزمني اليومي إلى SharedPreferences
            val prefs = getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
            prefs.edit().putLong("daily_time_limit_millis", dailyTimeLimitMillis).apply()
            Log.d("MainActivity2", "Daily time limit saved to SharedPreferences: $dailyTimeLimitMillis ms")
        }
    }

    private val pickImageLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            editProfileImageView.setImageURI(uri)
            showToast("Image selected: $uri")
        } else {
            showToast("No image selected.")
        }
    }

    // لطلب إذن الكاميرا
    private val requestCameraPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
        if (isGranted) {
            startCamera()
        } else {
            showToast("يلزم إذن الكاميرا لتمكين هذه الميزة.")
            resetChildModeState() // إعادة ضبط حالة وضع الطفل إذا لم يتم منح الإذن
        }
    }

    // --- دورة حياة النشاط (Activity Lifecycle) ---
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge() // تفعيل وضع الحواف
        setContentView(R.layout.activity_main2)

        // تهيئة واجهة المستخدم
        setupUI()

        // تحميل بيانات الوالدين والأطفال
        loadParentData()
        prepareChildListData()

        // تهيئة الكاميرا
        cameraExecutor = Executors.newSingleThreadExecutor()

        // ضبط سلوك زر الرجوع
        setupOnBackPressedCallback()

        // التعامل مع حواف الشاشة
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    override fun onResume() {
        super.onResume()
        checkForDefaultLauncherSetting() // التحقق من المشغل الافتراضي عند استئناف النشاط
        restoreAppState() // استعادة حالة وضع الطفل والحد الزمني اليومي
    }

    override fun onDestroy() {
        super.onDestroy()
        cameraExecutor.shutdown() // إغلاق ExecutorService الخاص بالكاميرا
    }

    // --- وظائف إعداد واجهة المستخدم (UI Setup Functions) ---
    private fun setupUI() {
        // زر المعلومات
        findViewById<ImageView>(R.id.imageView3).setOnClickListener {
            startActivity(Intent(this, about_screen::class.java))
        }


        // زر إضافة طفل
        addCardButton = findViewById(R.id.addCardButton)
        addCardButton.setOnClickListener {
            addChildLauncher.launch(Intent(this, Kidinformation::class.java))
        }

        // صورة تعديل ملف التعريف
        editProfileImageView = findViewById(R.id.imageView5)
        editProfileImageView.setOnClickListener {
            openGallery()
        }

        // زر الحد الزمني اليومي
        dailyTimeButton = findViewById(R.id.dailyTimeButton)
        dailyTimeButton.setOnClickListener {
            dailyTimeLauncher.launch(Intent(this, DailyTime::class.java))
        }

        // أقسام كلمة المرور
        setPasswordButton = findViewById(R.id.setPasswordButton)
        passwordInputSection = findViewById(R.id.passwordInputSection)
        newPasswordEditText = findViewById(R.id.newPasswordEditText)
        confirmPasswordEditText = findViewById(R.id.confirmPasswordEditText)
        savePasswordButton = findViewById(R.id.savePasswordButton)

        setPasswordButton.setOnClickListener {
            passwordInputSection.visibility = if (passwordInputSection.visibility == View.GONE) {
                newPasswordEditText.setText("")
                confirmPasswordEditText.setText("")
                View.VISIBLE
            } else {
                View.GONE
            }
        }

        savePasswordButton.setOnClickListener {
            saveParentPassword()
        }

        // مفتاح تبديل وضع الطفل (SwitchCompat)
        switchChildActive = findViewById(R.id.switchChildActive)
        previewView = findViewById(R.id.previewView)
        switchChildActive.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                // تفعيل وضع الطفل - يبدأ الكاميرا
                checkCameraPermissionAndOpenCamera()
            } else {
                // تعطيل وضع الطفل
                stopCamera()
                previewView.visibility = View.GONE // إخفاء معاينة الكاميرا
                resetChildModeState() // إعادة ضبط حالة وضع الطفل
                showToast("تم تعطيل وضع الطفل.")
            }
        }
    }

    // --- وظائف تحميل وحفظ البيانات (Data Loading & Saving Functions) ---
    private fun loadParentData() {
        parentNameTextView = findViewById(R.id.textView)
        val sharedPref = getSharedPreferences("user_prefs", Context.MODE_PRIVATE)
        val fullName = sharedPref.getString("full_name", "الوالد")
        parentNameTextView.text = fullName

        val defaultParentIdInt = -1
        val retrievedParentIdInt = sharedPref.getInt("parent_id", defaultParentIdInt)

        currentParentId = if (retrievedParentIdInt != defaultParentIdInt) {
            retrievedParentIdInt.toString()
        } else {
            "default_parent_id"
        }

        if (currentParentId == "default_parent_id") {
            Log.w("MainActivity2", "Parent ID not found in SharedPreferences or invalid. Using default.")
            showToast("Parent ID is not set. Please log in again.")
        }
    }

    private fun restoreAppState() {
        val prefs = getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
        isChildModeActive = prefs.getBoolean("is_child_mode_active", false)
        switchChildActive.isChecked = isChildModeActive // تحديث حالة السويتش
        Log.d("MainActivity2", "onResume: isChildModeActive = $isChildModeActive")

        dailyTimeLimitMillis = prefs.getLong("daily_time_limit_millis", 0L)
        Log.d("MainActivity2", "onResume: dailyTimeLimitMillis = $dailyTimeLimitMillis ms")
    }

    private fun saveParentPassword() {
        val newPassword = newPasswordEditText.text.toString()
        val confirmPassword = confirmPasswordEditText.text.toString()

        if (newPassword.isEmpty() || confirmPassword.isEmpty()) {
            showToast("الرجاء إدخال وتأكيد كلمة المرور.")
        } else if (newPassword != confirmPassword) {
            showToast("كلمات المرور غير متطابقة. الرجاء المحاولة مرة أخرى.")
        } else {
            val prefs = getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
            prefs.edit().putString("parent_password", newPassword).apply()

            showToast("تم حفظ كلمة مرور الوالدين بنجاح!")
            Log.d("MainActivity2", "Parent password saved: $newPassword")
            passwordInputSection.visibility = View.GONE
        }
    }

    // --- وظائف إدارة قائمة الأطفال (Child List Management Functions) ---
    private fun prepareChildListData() {
        // يمكنك هنا جلب بيانات الأطفال من قاعدة بيانات أو API إذا لزم الأمر
        val defaultChildren = listOf(
            Child("Shahd", R.drawable.user_alt_fill),
            Child("Amna", R.drawable.user_alt_fill),
            Child("Ahmed", R.drawable.user_alt_fill)
        )
        childlist.addAll(defaultChildren)
        recyclerViewChildAdapter?.notifyDataSetChanged()
    }

    private fun addNewChild(name: String) {
        val newChild = Child(name, R.drawable.user_alt_fill)
        childlist.add(newChild)
        recyclerViewChildAdapter?.notifyItemInserted(childlist.size - 1)
        recyclerView?.smoothScrollToPosition(childlist.size - 1)
    }

    override fun onItemDelete(position: Int) {
        if (position in 0 until childlist.size) {
            childlist.removeAt(position)
            showToast("Child deleted")
            recyclerViewChildAdapter?.notifyItemRemoved(position)
        }
    }

    // --- وظائف الكاميرا ومعالجة الصور (Camera & Image Processing Functions) ---
    private fun openGallery() {
        pickImageLauncher.launch("image/*")
    }

    private fun checkCameraPermissionAndOpenCamera() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startCamera()
        } else {
            requestCameraPermission.launch(Manifest.permission.CAMERA)
        }
    }

    private fun startCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)

        cameraProviderFuture.addListener({
            val cameraProvider: ProcessCameraProvider = cameraProviderFuture.get()

            val preview = Preview.Builder()
                .build()
                .also {
                    it.setSurfaceProvider(previewView.surfaceProvider)
                }

            imageCapture = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                .build()

            // استخدام الكاميرا الأمامية للتعرف على الوجه
            val cameraSelector = CameraSelector.DEFAULT_FRONT_CAMERA

            try {
                cameraProvider.unbindAll() // إيقاف أي استخدامات سابقة للكاميرا

                cameraProvider.bindToLifecycle(
                    this, cameraSelector, preview, imageCapture
                )

                previewView.visibility = View.VISIBLE // إظهار معاينة الكاميرا
                isCameraActive = true
                showToast("الكاميرا جاهزة. تلتقط صورة تلقائيًا...")

                // التقاط الصورة بعد 1 ثانية
                previewView.postDelayed({
                    takePhoto()
                }, 1000)

            } catch (exc: Exception) {
                Log.e("MainActivity2", "Use case binding failed", exc)
                showToast("خطأ في فتح الكاميرا: ${exc.message}")
                resetChildModeState() // إعادة ضبط حالة وضع الطفل عند حدوث خطأ
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun takePhoto() {
        val imageCapture = imageCapture ?: run {
            Log.e("MainActivity2", "Image capture use case is null. Cannot take photo.")
            showToast("الكاميرا ليست جاهزة لالتقاط الصورة.")
            resetChildModeState()
            return
        }

        imageCapture.takePicture(
            ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageCapturedCallback() {
                override fun onCaptureSuccess(image: androidx.camera.core.ImageProxy) {
                    val bitmap = imageProxyToBitmap(image)
                    image.close() // إغلاق ImageProxy بعد التحويل

                    bitmap?.let {
                        sendImageToVerificationServer(it, currentParentId)
                    } ?: run {
                        showToast("فشل تحويل الصورة.")
                        resetChildModeState()
                    }
                }

                override fun onError(exception: ImageCaptureException) {
                    Log.e("MainActivity2", "Photo capture failed: ${exception.message}", exception)
                    showToast("فشل التقاط الصورة: ${exception.message}")
                    resetChildModeState()
                }
            }
        )
    }

    private fun imageProxyToBitmap(image: androidx.camera.core.ImageProxy): Bitmap? {
        // تحويل ImageProxy إلى Bitmap
        val buffer = image.planes[0].buffer
        val bytes = ByteArray(buffer.remaining())
        buffer.get(bytes)
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
    }

    private fun sendImageToVerificationServer(bitmap: Bitmap, parentId: String) {
        // إخفاء معاينة الكاميرا بمجرد بدء إرسال الصورة
        previewView.visibility = View.GONE
        isCameraActive = false

        // حفظ Bitmap مؤقتًا في ملف لإرساله
        val filesDir = applicationContext.filesDir
        val file = File(filesDir, "image_to_upload.jpeg")
        val bos = ByteArrayOutputStream()
        // ضغط الصورة قبل الحفظ والإرسال
        bitmap.compress(Bitmap.CompressFormat.JPEG, 80, bos)
        val bitmapdata = bos.toByteArray()

        try {
            val fos = FileOutputStream(file)
            fos.write(bitmapdata)
            fos.flush()
            fos.close()
            Log.d("MainActivity2", "Bitmap saved to temporary file: ${file.absolutePath}")
        } catch (e: Exception) {
            Log.e("MainActivity2", "Error writing bitmap to file: ${e.message}", e)
            showToast("فشل إعداد ملف الصورة.")
            resetChildModeState()
            stopCamera()
            return
        }

        // إعداد أجزاء الطلب لـ Retrofit
        val requestFile = file.asRequestBody("image/jpeg".toMediaTypeOrNull())
        val imagePart = MultipartBody.Part.createFormData("image", file.name, requestFile)
        val parentIdPart = parentId.toRequestBody("text/plain".toMediaTypeOrNull())

        // إطلاق Coroutine لإجراء استدعاء الشبكة في ثريد الخلفية
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val response = RetrofitClient.apiService.verifyImage(imagePart, parentIdPart)
                launch(Dispatchers.Main) { // العودة إلى الثريد الرئيسي لتحديث UI
                    val prefs = getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
                    if (response.verified) {
                        // تم التحقق بنجاح (والد أو طفل)
                        if (response.matchedWith.contains("Parent", ignoreCase = true)) {
                            showToast("تم التحقق: هذا الوالد.")
                            isChildModeActive = false // تعطيل وضع الطفل إذا تم التعرف على الوالد
                            prefs.edit().putBoolean("is_child_mode_active", false).apply()
                            Log.d("MainActivity2", "Verification: Parent detected. isChildModeActive set to false.")
                            // يمكنك هنا الانتقال إلى الشاشة الرئيسية للوالد أو السماح بالخروج الطبيعي
                            // finish() // إذا كنت تريد الخروج من هذا النشاط
                        } else if (response.matchedWith.contains("Child", ignoreCase = true)) {
                            showToast("تم التحقق: هذا طفل.")
                            response.image?.let { imageUrl ->
                                Log.d("MainActivity2", "Child image URL from server: $imageUrl")
                            }
                            isChildModeActive = true // تفعيل وضع الطفل إذا تم التعرف على الطفل
                            prefs.edit().putBoolean("is_child_mode_active", true).apply()
                            Log.d("MainActivity2", "Verification: Child detected. isChildModeActive set to true.")
                            // في هذه الحالة، يبقى التطبيق في وضع الطفل (مثلاً، لا تسمح بالخروج بسهولة)
                        }
                    } else {
                        // لم يتم التحقق (مثل عدم وجود وجه، أو عدم تطابق)
                        // ستعرض الرسالة القادمة من الباك إند
                        showToast("لم يتم التحقق: ${response.message}")
                        // في هذه الحالات، يجب أن يكون وضع الطفل معطلاً
                        resetChildModeState()
                        Log.d("MainActivity2", "Verification: Not verified. isChildModeActive set to false. Message: ${response.message}")
                    }
                }
            } catch (e: Exception) {
                // التعامل مع أخطاء الشبكة (مثل عدم وجود اتصال، الخادم غير متاح)
                launch(Dispatchers.Main) {
                    showToast("خطأ في الاتصال بالخادم: ${e.message ?: "سبب غير معروف"}")
                    Log.e("MainActivity2", "Network error: ${e.message}", e)
                    resetChildModeState() // إعادة ضبط حالة وضع الطفل عند حدوث خطأ في الشبكة
                }
            } finally {
                // سيتم تنفيذ هذا دائمًا، سواء نجح الطلب أو فشل
                stopCamera() // إيقاف الكاميرا
                if (file.exists()) {
                    file.delete() // حذف الملف المؤقت
                    Log.d("MainActivity2", "Temporary file deleted: ${file.absolutePath}")
                }
            }
        }
    }

    private fun stopCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            val cameraProvider: ProcessCameraProvider = cameraProviderFuture.get()
            cameraProvider.unbindAll() // إلغاء ربط جميع حالات استخدام الكاميرا
            isCameraActive = false
        }, ContextCompat.getMainExecutor(this))
    }

    // --- وظائف المساعدة (Helper Functions) ---
    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }

    private fun resetChildModeState() {
        // وظيفة مساعدة لإعادة ضبط حالة وضع الطفل إلى "غير نشط"
        switchChildActive.isChecked = false
        isChildModeActive = false
        val prefs = getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
        prefs.edit().putBoolean("is_child_mode_active", false).apply()
        // تأكد أن الكاميرا قد توقفت ومعاينتها غير مرئية
        previewView.visibility = View.GONE
        stopCamera()
    }

    // --- وظائف التحكم في المشغل الافتراضي (Default Launcher Functions) ---
    private fun checkForDefaultLauncherSetting() {
        if (!isMyLauncherDefault()) {
            showDefaultLauncherPrompt()
        }
    }

    private fun isMyLauncherDefault(): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val roleManager = getSystemService(Context.ROLE_SERVICE) as RoleManager
            return roleManager.isRoleHeld(RoleManager.ROLE_HOME)
        } else {
            val packageName = packageName
            val intent = Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_HOME)
            }
            val resolveInfo = packageManager.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)
            return resolveInfo?.activityInfo?.packageName == packageName
        }
    }

    private fun showDefaultLauncherPrompt() {
        AlertDialog.Builder(this)
            .setTitle("تفعيل التحكم الأبوي الكامل")
            .setMessage("لكي يعمل تطبيقنا كمشغل افتراضي للجهاز ويوفر الحماية المطلوبة لطفلك، يرجى تعيينه كـ 'تطبيق الشاشة الرئيسية' الافتراضي. هل تريد الانتقال إلى الإعدادات الآن؟")
            .setPositiveButton("الانتقال للإعدادات") { dialog, which ->
                openDefaultLauncherSettings()
            }
            .setNegativeButton("لا، لاحقًا") { dialog, which ->
                showToast("لن يتم تفعيل التحكم الأبوي الكامل بدون تعيين التطبيق كمشغل افتراضي.")
            }
            .setCancelable(false)
            .show()
    }

    private fun openDefaultLauncherSettings() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                val intent = Intent(Settings.ACTION_HOME_SETTINGS)
                startActivity(intent)
            } else {
                val intent = Intent(Settings.ACTION_SETTINGS)
                showToast("يرجى البحث عن 'التطبيقات الافتراضية' ثم 'تطبيق الشاشة الرئيسية' لتعيين تطبيقنا.")
                startActivity(intent)
            }
        } catch (e: Exception) {
            Log.e("MainActivity2", "Error opening home settings: ${e.message}")
            showToast("لا يمكن فتح إعدادات المشغل مباشرة. يرجى البحث عنها يدويًا في الإعدادات -> التطبيقات.")
            startActivity(Intent(Settings.ACTION_SETTINGS))
        }
    }

    // --- سلوك زر الرجوع (OnBackPressedCallback) ---
    private fun setupOnBackPressedCallback() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            private val handler = Handler(Looper.getMainLooper())
            private var longPressRunnable: Runnable? = null

            override fun handleOnBackPressed() {
                if (isChildModeActive) {
                    // إذا كان وضع الطفل مفعلاً:
                    // ألغِ أي مهام سابقة للضغط المطول
                    longPressRunnable?.let { handler.removeCallbacks(it) }

                    showToast("اضغط مطولاً للخروج من المشغل")

                    // جدولة مهمة لتأكيد الضغط المطول
                    longPressRunnable = Runnable {
                        showToast("الخروج من وضع المشغل...")
                        // إطلاق شاشة HOME الافتراضية للجهاز
                        val intent = Intent(Intent.ACTION_MAIN)
                        intent.addCategory(Intent.CATEGORY_HOME)
                        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                        startActivity(intent)
                        finish() // إنهاء هذا النشاط (MainActivity2)
                    }
                    handler.postDelayed(longPressRunnable!!, 1500) // 1.5 ثانية للضغط المطول
                } else {
                    // إذا لم يكن وضع الطفل مفعلاً (الأب يستخدم الجهاز):
                    // اسمح بالخروج الطبيعي من النشاط الحالي (MainActivity2)
                    isEnabled = false // تعطيل هذا الـ Callback مؤقتاً لتجنب تكرار التنفيذ
                    onBackPressedDispatcher.onBackPressed() // استدعاء سلوك زر الرجوع الافتراضي للنظام
                    isEnabled = true // إعادة تفعيل الـ Callback
                }
            }
        })
    }
}