package com.example.myapplication
import com.google.gson.annotations.SerializedName
import okhttp3.MultipartBody // استورد هذا
import okhttp3.RequestBody // استورد هذا
import retrofit2.http.Multipart // استورد هذا
import retrofit2.http.POST
import retrofit2.http.Part // استورد هذا

interface ApiService {
    @Multipart // **** هذا هو التعديل الأساسي: نوع الطلب الآن هو Multipart ****
    @POST("verify")
    suspend fun verifyImage(
        // **** هذا هو التعديل: إرسال الصورة كـ MultipartBody.Part (ملف) ****
        @Part image: MultipartBody.Part, // اسم الحقل "image" كما يتوقعه الخادم
        // **** هذا هو التعديل: إرسال parent_id كـ RequestBody ****
        @Part("parent_id") parentId: RequestBody // اسم الحقل "parent_id"
    ): VerifyResponse
}

data class VerifyResponse(
    @SerializedName("image")
    val image: String?, // قد لا تكون موجودة دائمًا (في حالة الأب)، لذا اجعلها قابلة للـ null
    @SerializedName("matched_with")
    val matchedWith: String,
    @SerializedName("message")
    val message: String,
    @SerializedName("verified")
    val verified: Boolean
)