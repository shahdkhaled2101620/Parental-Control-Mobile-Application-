package com.example.myapplication

// هذا هو ملف Child.kt

data class Child(
    var title: String, // تم تغيير الاسم إلى title
    var image: Int     // تم تغيير الاسم إلى image وهو الآن فقط لموارد الصور المحلية (Int)
)
