package com.example.myapplication.data

import com.google.gson.annotations.SerializedName

data class ChildrenResponse(
    @SerializedName("status") val status: String,
    @SerializedName("data") val data: List<ChildData>
)

data class ChildData(
    @SerializedName("Child_ID") val childId: Int,
    @SerializedName("Full_Name") val fullName: String,
    @SerializedName("Image_Path") val imagePath: String,
    @SerializedName("Parent_ID") val parentId: Int,
    @SerializedName("Created_At") val createdAt: String
)