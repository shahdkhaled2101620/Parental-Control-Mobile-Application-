package com.example.myapplication
import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.Response
import com.android.volley.toolbox.JsonRequest
import com.android.volley.toolbox.Volley
import org.json.JSONArray
import org.json.JSONObject

private const val OVERLAY_PERMISSION_REQUEST_CODE = 101

class Apps : AppCompatActivity() {

    private lateinit var appList: List<AppModel>
    private lateinit var adapter: AppsAdapter
    val selectedApps = mutableListOf<AppModel>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_apps)

        val childId = intent.getIntExtra("child_id", -1)
        if (childId == -1) {
            Log.w("Apps", "child_id غير موجود")
        }
        Log.d("Apps", "Child ID: $childId")

        val btnBack: ImageView = findViewById(R.id.imageView10)
        btnBack.setOnClickListener {
            val intent = Intent(this, Kidinformation::class.java)
            startActivity(intent)
        }

        val confirmButton: Button = findViewById(R.id.confirmButton)
        confirmButton.setOnClickListener {
            val selectedPackageNames = ArrayList(selectedApps.map { it.packageName })
            saveSelectedPackages(selectedPackageNames)

            val sharedPref = getSharedPreferences("user_prefs", Context.MODE_PRIVATE)
            val parentId = sharedPref.getInt("parent_id", -1)

            if (parentId == -1) {
                Toast.makeText(this, "لم يتم العثور على معرف الوالد", Toast.LENGTH_SHORT).show()
                Log.e("Apps", "Parent ID غير موجود في SharedPreferences")
                return@setOnClickListener
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
                showOverlayPermissionDialogWithData(parentId, childId)
            } else {
                if (!isAccessibilityServiceEnabled(this, AppBlockerService::class.java)) {
                    showAccessibilityDialog()
                } else {
                    sendSelectedAppsToServer(selectedApps, parentId, childId)
                    navigateToKidsLauncher()
                }
            }
        }

        val recyclerView = findViewById<RecyclerView>(R.id.appsRecyclerView)
        recyclerView.layoutManager = GridLayoutManager(this, 3)

        val packageManager = packageManager
        val installedApps = packageManager.getInstalledApplications(PackageManager.GET_META_DATA)

        appList = installedApps.mapNotNull {
            val launchIntent = packageManager.getLaunchIntentForPackage(it.packageName)
            if (launchIntent != null) {
                AppModel(
                    name = packageManager.getApplicationLabel(it).toString(),
                    packageName = it.packageName
                )
            } else {
                null
            }
        }.sortedBy { it.name }

        adapter = AppsAdapter(this, appList, selectedApps, packageManager) { app ->
            if (selectedApps.contains(app)) {
                selectedApps.remove(app)
            } else {
                selectedApps.add(app)
            }
            adapter.notifyDataSetChanged()
        }

        recyclerView.adapter = adapter
        loadPreviousSelectedPackages()
    }

    private fun saveSelectedPackages(selectedPackages: ArrayList<String>) {
        val prefs = getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
        prefs.edit().putString("selected_packages_set", selectedPackages.joinToString(",")).apply()
        Log.d("Apps", "Selected packages saved to SharedPreferences: $selectedPackages")
    }

    private fun loadPreviousSelectedPackages() {
        val prefs = getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
        val selectedPackagesString = prefs.getString("selected_packages_set", null)
        val previouslySelectedPackageNames =
            selectedPackagesString?.split(",")?.toSet() ?: emptySet()

        selectedApps.clear()

        for (app in appList) {
            if (previouslySelectedPackageNames.contains(app.packageName)) {
                selectedApps.add(app)
            }
        }

        adapter.notifyDataSetChanged()
        Log.d("Apps", "Loaded previous selected apps: ${selectedApps.map { it.name }}")
    }

    private fun showOverlayPermissionDialogWithData(parentId: Int, childId: Int) {
        AlertDialog.Builder(this)
            .setTitle("إذن الرسم فوق التطبيقات")
            .setMessage("يحتاج التطبيق إلى إذن لعرض شاشات الحماية فوق التطبيقات الأخرى. يرجى تفعيله في الإعدادات.")
            .setPositiveButton("تفعيل الآن") { dialog, _ ->
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                intent.putExtra("parent_id", parentId)
                intent.putExtra("child_id", childId)
                startActivityForResult(intent, OVERLAY_PERMISSION_REQUEST_CODE)
                dialog.dismiss()
            }
            .setNegativeButton("ليس الآن") { dialog, _ ->
                dialog.dismiss()
            }
            .setCancelable(false)
            .show()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == OVERLAY_PERMISSION_REQUEST_CODE) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && Settings.canDrawOverlays(this)) {
                val sharedPref = getSharedPreferences("user_prefs", Context.MODE_PRIVATE)
                val parentId = sharedPref.getInt("parent_id", -1)
                val childId = intent.getIntExtra("child_id", -1)

                if (parentId != -1 && childId != -1) {
                    if (!isAccessibilityServiceEnabled(this, AppBlockerService::class.java)) {
                        showAccessibilityDialog()
                    } else {
                        sendSelectedAppsToServer(selectedApps, parentId, childId)
                        navigateToKidsLauncher()
                    }
                } else {
                    Toast.makeText(this, "خطأ في البيانات", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "إذن الرسم فوق التطبيقات مطلوب", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun sendSelectedAppsToServer(apps: List<AppModel>, parentId: Int, childId: Int) {
        val requestQueue = Volley.newRequestQueue(this)
        val urlCreateApps = "http://168.231.108.230/ParentalCo/create_apps.php"

        val jsonArray = JSONArray()
        for (app in apps) {
            val jsonApp = JSONObject()
            jsonApp.put("app_name", app.name)
            jsonApp.put("app_status", 1)
            jsonApp.put("parent_id", parentId)
            jsonApp.put("limit_time", "01:00:00")
            jsonArray.put(jsonApp)
        }

        val request = object : JsonRequest<JSONObject>(
            Method.POST, urlCreateApps, jsonArray.toString(),
            { response ->
                try {
                    Log.d("Apps", "Server response: $response")
                    val status = response.getString("status")
                    if (status == "success") {
                        val appIdsArray = response.getJSONArray("app_ids")
                        val appIdsList = mutableListOf<Int>()
                        for (i in 0 until appIdsArray.length()) {
                            appIdsList.add(appIdsArray.getInt(i))
                        }
                        sendAssignAppsToChild(childId, appIdsList)
                    } else {
                        Log.e("Apps", "Server returned failure: $response")
                    }
                } catch (e: Exception) {
                    Log.e("Apps", "Error parsing server response: ${e.message}")
                }
            },
            { error ->
                Log.e("Apps", "Volley error: ${error.message}")
            }
        ) {
            override fun parseNetworkResponse(response: com.android.volley.NetworkResponse?): com.android.volley.Response<JSONObject> {
                return try {
                    val jsonString = String(response?.data ?: ByteArray(0), Charsets.UTF_8)
                    com.android.volley.Response.success(JSONObject(jsonString), com.android.volley.Cache.Entry())
                } catch (e: Exception) {
                    com.android.volley.Response.error(com.android.volley.ParseError(e))
                }
            }

            override fun getBodyContentType(): String {
                return "application/json; charset=utf-8"
            }
        }

        requestQueue.add(request)
    }

    private fun sendAssignAppsToChild(childId: Int, appIds: List<Int>) {
        val requestQueue = Volley.newRequestQueue(this)
        val urlAssign = "http://168.231.108.230/ParentalCo/assign_apps_to_child.php"

        val jsonBody = JSONObject().apply {
            put("child_id", childId)
            put("app_ids", JSONArray(appIds))
        }

        val request = object : JsonRequest<JSONObject>(
            Method.POST, urlAssign, jsonBody.toString(),
            { response ->
                try {
                    val status = response.getString("status")
                    if (status == "success") {
                        Log.d("Apps", "تطبيقات الطفل تم ربطها بنجاح")
                    } else {
                        val message = response.getString("message")
                        Log.e("Apps", "فشل في ربط التطبيقات: $message")
                    }
                } catch (e: Exception) {
                    Log.e("Apps", "Error parsing assign response: ${e.message}")
                }
            },
            { error ->
                Log.e("Apps", "Volley error in assign request: ${error.message}")
            }
        ) {
            override fun parseNetworkResponse(response: com.android.volley.NetworkResponse?): com.android.volley.Response<JSONObject> {
                return try {
                    val jsonString = String(response?.data ?: ByteArray(0), Charsets.UTF_8)
                    com.android.volley.Response.success(JSONObject(jsonString), com.android.volley.Cache.Entry())
                } catch (e: Exception) {
                    com.android.volley.Response.error(com.android.volley.ParseError(e))
                }
            }

            override fun getBodyContentType(): String {
                return "application/json; charset=utf-8"
            }
        }

        requestQueue.add(request)
    }

    private fun navigateToKidsLauncher() {
        val intent = Intent(this, KidsLauncher::class.java)
        startActivity(intent)
        finish()
    }

    private fun isAccessibilityServiceEnabled(context: Context, service: Class<out AccessibilityService>): Boolean {
        val expectedComponentName = "${context.packageName}/${service.name}"
        val enabledServices = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false

        return enabledServices.split(":").any { it.equals(expectedComponentName, ignoreCase = true) }
    }

    private fun showAccessibilityDialog() {
        AlertDialog.Builder(this)
            .setTitle("تفعيل خدمة إمكانية الوصول")
            .setMessage("يحتاج التطبيق لتفعيل خدمة إمكانية الوصول ليعمل بشكل صحيح. هل تريد تفعيلها الآن؟")
            .setPositiveButton("تفعيل الآن") { dialog, _ ->
                val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                startActivity(intent)
                dialog.dismiss()
            }
            .setNegativeButton("إلغاء") { dialog, _ ->
                dialog.dismiss()
            }
            .setCancelable(false)
            .show()
    }
}
