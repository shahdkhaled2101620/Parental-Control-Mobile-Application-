// File: com/example/myapplication/AppApiService.kt (أو في حزمة api إذا كنت تستخدمها)
package com.example.myapplication

import com.google.gson.JsonObject
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Query
import com.example.myapplication.data.AppCreationRequest // <--- استيراد نموذج البيانات الجديد

interface AppApiService {

    // Endpoint for get_child_id.php
    @POST("get_child_id.php")
    fun getChildId(@Body requestBody: JsonObject): Call<JsonObject>

    // Endpoint for create_apps.php
    // سيتم تحويل قائمة AppCreationRequest تلقائيًا إلى مصفوفة JSON بواسطة Gson
    @POST("create_apps.php")
    fun createApps(@Body apps: List<AppCreationRequest>): Call<JsonObject> // <--- تم التعديل هنا

    // Endpoint for get_all_apps_by_parent.php
    @GET("get_all_apps_by_parent.php")
    fun getAllAppsByParent(@Query("parent_id") parentId: Int): Call<JsonObject>

    // Endpoint for assign_apps_to_child.php
    @POST("assign_apps_to_child.php")
    fun assignAppsToChild(@Body requestBody: JsonObject): Call<JsonObject>
}