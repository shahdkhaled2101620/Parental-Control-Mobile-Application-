package com.example.myapplication

import android.os.Parcel
import android.os.Parcelable

data class AppModel(
    val name: String,
    val packageName: String
) : Parcelable {
    constructor(parcel: Parcel) : this(
        parcel.readString() ?: "",
        parcel.readString() ?: ""
    )

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeString(name)
        parcel.writeString(packageName)
    }

    override fun describeContents(): Int = 0

    companion object CREATOR : Parcelable.Creator<AppModel> {
        override fun createFromParcel(parcel: Parcel): AppModel {
            return AppModel(parcel)
        }

        override fun newArray(size: Int): Array<AppModel?> {
            return arrayOfNulls(size)
        }
    }
}
