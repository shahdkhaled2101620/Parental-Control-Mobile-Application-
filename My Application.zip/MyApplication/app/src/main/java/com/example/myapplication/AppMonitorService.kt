package com.example.myapplication

import android.app.Service
import android.app.usage.UsageStats
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Log
import java.util.Calendar
import java.util.Locale // استيراد جديد لـ Locale
import java.util.concurrent.TimeUnit
import android.app.AppOpsManager // استيراد جديد لـ AppOpsManager

class AppMonitorService : Service() {

    private var dailyTimeLimitMillis: Long = 0L // الحد الزمني اليومي بالميلي ثانية
    private var isMonitoringActive = false // هل المراقبة مفعلة حاليًا؟
    private lateinit var handler: Handler // للتعامل مع الـ Runnable
    private lateinit var usageStatsManager: UsageStatsManager
    private val refreshIntervalMs = 1000L // تم تغيير الاسم إلى camelCase

    // متغير لتخزين الوقت الكلي الذي قضاه الطفل اليوم.
    private var totalUsageTodayMillis: Long = 0L

    // المفتاح لحفظ واستعادة الوقت الكلي المستغرق في SharedPreferences (تم تغيير الاسم)
    private val prefKeyTotalUsageToday = "total_usage_today_millis"
    private val prefKeyLastUsageDate = "last_usage_date" // (تم تغيير الاسم)

    private val monitorRunnable = object : Runnable {
        override fun run() {
            if (isMonitoringActive) {
                // تحقق من صلاحية Usage Stats في كل تكرار لضمان أنها لا تزال ممنوحة
                if (!checkUsageStatsPermission(this@AppMonitorService)) {
                    Log.e("AppMonitorService", "Usage Stats permission lost or not granted. Stopping monitoring.")
                    stopMonitoring()
                    return
                }

                // تحديث الوقت الكلي المستغرق لهذا اليوم
                updateTotalUsageToday()

                Log.d("AppMonitorService", "Total usage today: ${formatMillis(totalUsageTodayMillis)} / Limit: ${formatMillis(dailyTimeLimitMillis)}")

                if (dailyTimeLimitMillis > 0 && totalUsageTodayMillis >= dailyTimeLimitMillis) {
                    Log.w("AppMonitorService", "Daily time limit reached! Launching freeze screen.")
                    launchFreezeScreen()
                    stopMonitoring() // أوقف المراقبة بمجرد الوصول إلى الحد
                } else {
                    handler.postDelayed(this, refreshIntervalMs) // استخدام الاسم الجديد
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        Log.d("AppMonitorService", "Service onCreate")
        handler = Handler(Looper.getMainLooper())
        usageStatsManager = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        loadDailyTimeLimit() // حمل الحد الزمني عند إنشاء الخدمة
        loadTotalUsageToday() // حمل الوقت الكلي المستغرق لليوم الحالي
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.d("AppMonitorService", "Service onStartCommand")
        if (intent?.action == "START_MONITORING") {
            startMonitoring()
        } else if (intent?.action == "STOP_MONITORING") {
            stopMonitoring()
        }
        return START_STICKY // أعد تشغيل الخدمة إذا تم إنهاؤها بواسطة النظام
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null // هذه الخدمة لا تحتاج لـ binding
    }

    fun setDailyTimeLimit(limitMillis: Long) {
        dailyTimeLimitMillis = limitMillis
        // حفظ الحد الزمني في SharedPreferences
        val prefs = getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
        prefs.edit().putLong("daily_time_limit_millis", dailyTimeLimitMillis).apply()
        Log.d("AppMonitorService", "Daily time limit set to: $dailyTimeLimitMillis ms")
    }

    fun startMonitoring() { // لم يتم تغييرها إلى private حاليًا، لأنه قد نحتاج لاستدعائها من الخارج
        if (!isMonitoringActive) {
            Log.d("AppMonitorService", "Starting monitoring...")
            isMonitoringActive = true
            loadTotalUsageToday() // تأكد من تحميل الوقت لليوم الحالي قبل البدء
            handler.post(monitorRunnable)
        } else {
            Log.d("AppMonitorService", "Monitoring already active.")
        }
    }

    fun stopMonitoring() { // لم يتم تغييرها إلى private حاليًا
        if (isMonitoringActive) {
            Log.d("AppMonitorService", "Stopping monitoring...")
            isMonitoringActive = false
            handler.removeCallbacks(monitorRunnable)
            // لا يتم مسح totalUsageTodayMillis هنا. يتم مسحه عند بدء يوم جديد.
            // يمكنك حفظه إذا أردت استئناف من نفس النقطة لاحقًا في نفس اليوم.
        } else {
            Log.d("AppMonitorService", "Monitoring already stopped.")
        }
    }

    private fun loadDailyTimeLimit() {
        val prefs = getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
        dailyTimeLimitMillis = prefs.getLong("daily_time_limit_millis", 0L)
        Log.d("AppMonitorService", "Loaded daily time limit: $dailyTimeLimitMillis ms")
    }

    private fun updateTotalUsageToday() {
        val calendar = Calendar.getInstance()
        val currentDay = calendar.get(Calendar.DAY_OF_YEAR)
        val currentYear = calendar.get(Calendar.YEAR)

        val prefs = getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
        val lastUsageDay = prefs.getInt(prefKeyLastUsageDate + "_day", -1) // استخدام الاسم الجديد
        val lastUsageYear = prefs.getInt(prefKeyLastUsageDate + "_year", -1) // استخدام الاسم الجديد

        // إذا كان اليوم الجديد، قم بمسح الوقت الكلي المستغرق
        if (currentDay != lastUsageDay || currentYear != lastUsageYear) {
            Log.d("AppMonitorService", "New day detected. Resetting total usage.")
            totalUsageTodayMillis = 0L
            prefs.edit()
                .putInt(prefKeyLastUsageDate + "_day", currentDay) // استخدام الاسم الجديد
                .putInt(prefKeyLastUsageDate + "_year", currentYear) // استخدام الاسم الجديد
                .putLong(prefKeyTotalUsageToday, 0L) // إعادة تعيين الوقت الكلي في SharedPreferences (استخدام الاسم الجديد)
                .apply()
        }

        val currentTime = System.currentTimeMillis()
        val twentyFourHoursAgo = currentTime - TimeUnit.DAYS.toMillis(1) // آخر 24 ساعة للتحقق

        val queryUsageStats = usageStatsManager.queryUsageStats(
            UsageStatsManager.INTERVAL_DAILY,
            twentyFourHoursAgo,
            currentTime
        )

        var currentAppsUsageMillis = 0L
        if (queryUsageStats != null && queryUsageStats.isNotEmpty()) {
            for (usageStats in queryUsageStats) {
                // استبعاد حزم النظام واللانشرات والتطبيق الخاص بك من حساب الوقت
                if (!systemAndLauncherPackages.contains(usageStats.packageName)) {
                    currentAppsUsageMillis += usageStats.totalTimeInForeground
                }
            }
        }
        // قم بتعيين totalUsageTodayMillis إلى الوقت الكلي المستغرق اليوم
        totalUsageTodayMillis = currentAppsUsageMillis

        // حفظ totalUsageTodayMillis في SharedPreferences باستمرار
        prefs.edit().putLong(prefKeyTotalUsageToday, totalUsageTodayMillis).apply() // استخدام الاسم الجديد
    }

    private fun loadTotalUsageToday() {
        val prefs = getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
        totalUsageTodayMillis = prefs.getLong(prefKeyTotalUsageToday, 0L) // استخدام الاسم الجديد
        val lastUsageDay = prefs.getInt(prefKeyLastUsageDate + "_day", -1) // استخدام الاسم الجديد
        val lastUsageYear = prefs.getInt(prefKeyLastUsageDate + "_year", -1) // استخدام الاسم الجديد

        val calendar = Calendar.getInstance()
        val currentDay = calendar.get(Calendar.DAY_OF_YEAR)
        val currentYear = calendar.get(Calendar.YEAR)

        // إذا كان اليوم الجديد، قم بإعادة تعيين الوقت الكلي المستغرق
        if (currentDay != lastUsageDay || currentYear != lastUsageYear) {
            totalUsageTodayMillis = 0L
            prefs.edit()
                .putInt(prefKeyLastUsageDate + "_day", currentDay) // استخدام الاسم الجديد
                .putInt(prefKeyLastUsageDate + "_year", currentYear) // استخدام الاسم الجديد
                .putLong(prefKeyTotalUsageToday, 0L) // استخدام الاسم الجديد
                .apply()
        }
        Log.d("AppMonitorService", "Loaded total usage today: ${formatMillis(totalUsageTodayMillis)}")
    }

    private fun launchFreezeScreen() {
        val intent = Intent(this, freeze_screen::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        startActivity(intent)
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("AppMonitorService", "Service onDestroy")
        stopMonitoring() // تأكد من إزالة الـ callbacks عند تدمير الخدمة
    }

    // دالة مساعدة لتنسيق الوقت (للتسجيل)
    private fun formatMillis(millis: Long): String {
        val hours = TimeUnit.MILLISECONDS.toHours(millis)
        val minutes = TimeUnit.MILLISECONDS.toMinutes(millis) % 60
        val seconds = TimeUnit.MILLISECONDS.toSeconds(millis) % 60
        return String.format(Locale.getDefault(), "%02d:%02d:%02d", hours, minutes, seconds) // إضافة Locale
    }

    // قائمة حزم النظام واللانشرات التي يجب تجاهلها (مكررة من AppBlockerService)
    // يمكن نقل هذه القائمة إلى ملف ثابت مشترك إذا أصبحت كبيرة جدًا
    private val systemAndLauncherPackages = setOf(
        this.packageName,
        "com.android.systemui",
        "com.android.launcher",
        "com.google.android.apps.nexuslauncher",
        "com.sec.android.app.launcher",
        "com.miui.home",
        "com.huawei.android.launcher",
        "com.android.settings",
        "com.google.android.inputmethod.latin",
        "android",
        "com.android.vending",
        "com.google.android.gms",
        "com.google.android.permissioncontroller",
        "com.android.packageinstaller",
        "com.google.android.apps.wellbeing",
        "com.samsung.android.app.galaxyfinder",
        "com.samsung.android.app.taskedge",
        "com.samsung.android.app.genie",
        "com.android.chrome",
        "com.android.incallui",
        "com.google.android.dialer",
        "com.samsung.android.app.contacts",
        "com.android.contacts",
        "com.samsung.android.messaging",
        "com.google.android.apps.messaging",
        "com.samsung.android.calendar",
        "com.google.android.calendar",
        "com.samsung.android.app.filter",
        "com.android.documentsui",
        "com.android.providers.media",
        "com.android.camera",
        "com.samsung.android.app.camera",
        "com.google.android.googlequicksearchbox",
        "com.google.android.launcher",
        "com.android.launcher3",
        "com.oneplus.android.launcher",
        "com.oppo.launcher",
        "com.vivo.launcher",
        "com.htc.launcher",
        "com.lge.launcher",
        "com.sonymobile.home",
        "com.samsung.android.app.lockscreen",
        "com.sec.android.app.sbrowser",
        "com.samsung.android.honeyboard",
        "com.google.android.inputmethod.latin.debug",
        "com.touchtype.swiftkey",
        "com.nuance.swype.dtc",
        "com.sec.android.inputmethod",
        "com.google.android.apps.assistant",
        "com.google.android.googlequicksearchbox"
    )

    // دالة مساعدة للتحقق من إذن Usage Stats (تم تعديلها للتوافق مع API 24)
    private fun checkUsageStatsPermission(context: Context): Boolean {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            // على API 29+، يمكن استخدام checkOpNoThrow بأمان
            appOps.checkOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                android.os.Process.myUid(),
                context.packageName
            )
        } else {
            @Suppress("DEPRECATION") // لقمع التحذير على checkOpNoThrow للإصدارات القديمة
            appOps.checkOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                android.os.Process.myUid(),
                context.packageName
            )
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }
}