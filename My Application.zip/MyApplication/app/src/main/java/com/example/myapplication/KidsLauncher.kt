package com.example.myapplication
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import android.util.Log
import android.content.Context

class KidsLauncher : AppCompatActivity() {

    // لا يوجد هنا PARENT_PASSWORD ثابت أو متغير
    // لأن KidsLauncher لن يتعامل مع كلمة المرور للخروج.

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // إزالة الفلاجز التي كانت تستخدم لتثبيت الشاشة وإخفاء شريط النظام القسري
        window.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        setContentView(R.layout.activity_kids_launcher)

        val recyclerView = findViewById<RecyclerView>(R.id.appsRecyclerView)
        val emptyTextView = findViewById<TextView>(R.id.emptyTextView)
        val titleTextView = findViewById<TextView>(R.id.idtitle)

        // إزالة أي إشارات إلى passwordLayout أو passwordEditText أو exitButton
        //val passwordLayout = findViewById<LinearLayout>(R.id.passwordLayout)
        //val passwordEditText = findViewById<EditText>(R.id.passwordEditText)
        //val exitButton = findViewById<Button>(R.id.exitButton)

        // *** التعديل الرئيسي هنا: تحميل التطبيقات من SharedPreferences ***
        val selectedPackageNamesFromPrefs = loadSelectedPackagesFromPrefs()

        Log.d("KidsLauncher", "Selected packages loaded from SharedPreferences: $selectedPackageNamesFromPrefs")

        val packageManager = packageManager
        val allowedApps = selectedPackageNamesFromPrefs.mapNotNull { packageName ->
            try {
                val appInfo = packageManager.getApplicationInfo(packageName, 0)
                val appName = packageManager.getApplicationLabel(appInfo).toString()
                AppModel(name = appName, packageName = packageName)
            } catch (e: Exception) {
                Log.e("KidsLauncher", "Error getting app info for $packageName: ${e.message}")
                null
            }
        }.sortedBy { it.name }

        if (allowedApps.isEmpty()) {
            emptyTextView.visibility = View.VISIBLE
            recyclerView.visibility = View.GONE
            Log.d("KidsLauncher", "No allowed apps found. Displaying empty message.")
        } else {
            emptyTextView.visibility = View.GONE
            recyclerView.visibility = View.VISIBLE
            Log.d("KidsLauncher", "Allowed apps: ${allowedApps.map { it.name }}")

            recyclerView.layoutManager = GridLayoutManager(this, 3)

            val adapter = AppsAdapter(
                context = this,
                appList = allowedApps,
                selectedApps = emptyList(), // هنا لا يتم استخدامها للاختيار، فقط للعرض
                packageManager = packageManager,
                onAppClick = { app ->
                    Log.d("KidsLauncher", "App clicked: ${app.name} (${app.packageName})")
                    // AppBlockerService هو الذي سيتعامل مع كلمة المرور
                    openApp(app.packageName)
                }
            )
            recyclerView.adapter = adapter
        }

        // *** إزالة كود النقر الطويل لإظهار كلمة المرور ***
        // titleTextView.setOnLongClickListener {
        //     passwordLayout.visibility = View.VISIBLE
        //     true
        // }

        // *** إزالة كود زر الخروج بالكامل ***
        // exitButton.setOnClickListener {
        //     val enteredPassword = passwordEditText.text.toString()
        //     if (enteredPassword == PARENT_PASSWORD) {
        //         val intent = Intent(this, MainActivity::class.java)
        //         intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        //         startActivity(intent)
        //         finish()
        //     } else {
        //         Toast.makeText(this, "كلمة المرور غير صحيحة!", Toast.LENGTH_SHORT).show()
        //     }
        // }

        // إزالة أي كود يتعلق بـ systemUiVisibilityChangeListener أو onBackPressedDispatcher أو startScreenPinning/stopScreenPinning
        // إذا كنت قد وضعت startLockTask() هنا في السابق، قم بإزالته أيضاً إذا لم تعد تريده
        // startLockTask() // إزالة هذا السطر إذا كنت لا تريد تفعيل تثبيت الشاشة تلقائيا
    }

    // دالة جديدة لتحميل التطبيقات المختارة من SharedPreferences
    private fun loadSelectedPackagesFromPrefs(): List<String> {
        val prefs = getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
        val selectedPackagesString = prefs.getString("selected_packages_set", null)
        return selectedPackagesString?.split(",")?.filter { it.isNotEmpty() } ?: emptyList()
    }

    // إزالة دالة hideSystemUI() بالكامل

    override fun onResume() {
        super.onResume()
        // يمكن تركها فارغة أو لإعادة تحميل التطبيقات إذا كانت تتغير أثناء التشغيل
        // reloadApps() // دالة يمكن إضافتها لتحديث قائمة التطبيقات المعروضة
    }

    // إزالة دالة onWindowFocusChanged() بالكامل

    // إزالة دالة onKeyDown() بالكامل

    private fun openApp(packageName: String) {
        try {
            val intent = packageManager.getLaunchIntentForPackage(packageName)
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                Log.d("KidsLauncher", "Attempting to start app: $packageName")
                startActivity(intent)
            } else {
                Log.e("KidsLauncher", "Launch intent is null for $packageName. App might be disabled or not a launcher app.")
                Toast.makeText(this, "لا يمكن فتح التطبيق: $packageName", Toast.LENGTH_LONG).show()
            }
        } catch (e: Exception) {
            Log.e("KidsLauncher", "Error opening app $packageName: ${e.message}", e)
            Toast.makeText(this, "خطأ في فتح التطبيق: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
        }
    }

}