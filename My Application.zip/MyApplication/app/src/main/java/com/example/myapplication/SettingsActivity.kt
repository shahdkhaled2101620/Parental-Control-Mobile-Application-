package com.example.myapplication


import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class SettingsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        val editTextApps: EditText = findViewById(R.id.editTextApps)
        val saveButton: Button = findViewById(R.id.saveButton)

        val sharedPreferences: SharedPreferences = getSharedPreferences("KidsLauncherPrefs", MODE_PRIVATE)

        editTextApps.setText(sharedPreferences.getString("allowed_apps", "com.whatsapp,com.youtube.kids"))

        saveButton.setOnClickListener {
            val newApps = editTextApps.text.toString()
            sharedPreferences.edit().putString("allowed_apps", newApps).apply()
            Toast.makeText(this, "✅ تم تحديث التطبيقات المسموح بها!", Toast.LENGTH_SHORT).show()
        }
    }
}
