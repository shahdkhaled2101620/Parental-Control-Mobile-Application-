package com.example.myapplication
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.android.volley.Request
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import org.json.JSONObject

class MainActivity : AppCompatActivity() {

    private lateinit var emailEditText: EditText
    private lateinit var passwordEditText: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        // تهيئة حقول الإدخال باستخدام الـ IDs الصحيحة من activity_main.xml
        emailEditText = findViewById(R.id.emailEditText)
        passwordEditText = findViewById(R.id.passwordEditText)

        val loginButton = findViewById<Button>(R.id.button2) // الزر الخاص بتسجيل الدخول
        loginButton.setOnClickListener {
            val email = emailEditText.text.toString().trim()
            val password = passwordEditText.text.toString().trim()

            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "الرجاء إدخال البريد الإلكتروني وكلمة المرور", Toast.LENGTH_SHORT).show()
                return@setOnClickListener // إنهاء دالة setOnClickListener
            }

            // استدعاء دالة تسجيل الدخول التي تتصل بالـ API
            performLogin(email, password)
        }

        // الزر الخاص بالاشتراك (Sign Up)
        val signUpButton = findViewById<Button>(R.id.button3)
        signUpButton.setOnClickListener {
            val intent = Intent(this, signActivity::class.java)
            startActivity(intent)
        }

        // TextView الخاص بـ "نسيت كلمة المرور"
        val forgetPasswordTextView = findViewById<TextView>(R.id.textView6)
        forgetPasswordTextView.setOnClickListener {
            val intent = Intent(this, ForgetpasswordActivity::class.java)
            startActivity(intent)
        }
    }

    /**
     * تقوم بإجراء طلب تسجيل دخول إلى الـ API باستخدام البريد الإلكتروني وكلمة المرور.
     * @param email البريد الإلكتروني للمستخدم.
     * @param password كلمة مرور المستخدم.
     */
    private fun performLogin(email: String, password: String) {
        // نقطة نهاية الـ API لتسجيل الدخول
        val url = "http://168.231.108.230/ParentalCo/login.php"
        // إنشاء قائمة انتظار طلبات Volley (إذا لم تكن موجودة بالفعل)
        val requestQueue = Volley.newRequestQueue(this)

        // بناء جسم الطلب بصيغة JSON
        val jsonBody = JSONObject().apply {
            put("email", email)
            put("password", password)
        }

        // إنشاء طلب POST (JsonObjectRequest)
        val jsonRequest = JsonObjectRequest(Request.Method.POST, url, jsonBody,
            { response ->
                // يتم استدعاء هذا الجزء عند استلام استجابة ناجحة من الخادم (حتى لو كانت حالة "error" من API)
                val status = response.getString("status").trim().lowercase()
                val message = response.getString("message")

                if (status == "success") {
                    // تسجيل الدخول ناجح
                    Toast.makeText(this, message, Toast.LENGTH_LONG).show()

                    // استخراج بيانات المستخدم الإضافية من استجابة الـ API (مثل parent_id, full_name)
                    // هذا الجزء يتوافق مع كائن "user" في استجابة PHP
                    val userObject = response.optJSONObject("user")
                    if (userObject != null) {
                        val parentId = userObject.getInt("parent_id")
                        val fullName = userObject.getString("full_name")
                        val userEmail = userObject.getString("email")

                        // يمكنك الآن استخدام parentId و fullName و userEmail في تطبيقك
                        // على سبيل المثال، حفظها في Shared Preferences لاستخدامها في الأنشطة الأخرى:
                        val sharedPref = getSharedPreferences("user_prefs", MODE_PRIVATE)
                        with(sharedPref.edit()) {
                            putInt("parent_id", parentId)
                            putString("full_name", fullName)
                            putString("email", userEmail)
                            apply() // أو commit()
                        }

                        // سجل لغرض التصحيح (Debugging)
                        android.util.Log.d("LOGIN_SUCCESS", "Parent ID: $parentId, Full Name: $fullName, Email: $userEmail")
                    }

                    // الانتقال إلى الشاشة التالية بعد تسجيل الدخول الناجح
                    val intent = Intent(this, add_child1::class.java)
                    startActivity(intent)
                    finish() // إغلاق شاشة تسجيل الدخول لمنع المستخدم من العودة إليها بزر الرجوع
                } else {
                    // تسجيل الدخول فاشل بناءً على رسالة الـ API (مثل "Invalid email or password.")
                    Toast.makeText(this, "خطأ في تسجيل الدخول: $message", Toast.LENGTH_LONG).show()
                }
            },
            { error ->
                // يتم استدعاء هذا الجزء عند حدوث خطأ في الشبكة (مثل عدم وجود اتصال، أو خطأ 404/500 من الخادم)
                Toast.makeText(this, "خطأ في الاتصال: ${error.message}", Toast.LENGTH_LONG).show()
                // طباعة الخطأ الكامل لتصحيح الأخطاء في Logcat
                error.printStackTrace()
            })

        // إضافة الطلب إلى قائمة انتظار Volley لإرساله
        requestQueue.add(jsonRequest)
    }
}