package com.example.myapplication

import android.content.Context

class SharedPrefHelper(context: Context) {
    private val sharedPreferences = context.getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)

    fun saveDailyTime(seconds: Int) {
        sharedPreferences.edit().putInt("daily_time", seconds).apply()
    }

    fun getDailyTime(): Int {
        return sharedPreferences.getInt("daily_time", 0)
    }

    fun clearDailyTime() {
        sharedPreferences.edit().remove("daily_time").apply()
    }
}
