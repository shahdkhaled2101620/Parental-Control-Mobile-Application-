package com.example.myapplication

import android.app.AlarmManager
import android.app.Dialog
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.CountDownTimer
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.util.*

class DailyTime : AppCompatActivity() {

    private var timeSelected: Int = 0
    private var timeCountDown: CountDownTimer? = null
    private var timeProgress = 0
    private var pauseOffSet: Long = 0
    private var isStart = true

    private lateinit var sharedPrefHelper: SharedPrefHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_daily_time)

        sharedPrefHelper = SharedPrefHelper(this)

        val addBtn: ImageButton = findViewById(R.id.btnAdd)
        val startBtn: Button = findViewById(R.id.btnPlayPause)
        val resetBtn: ImageButton = findViewById(R.id.ib_reset)
        val addTimeTv: TextView = findViewById(R.id.tv_addTime)
        val btnBack: ImageView = findViewById(R.id.imageView14)
        val progressBar: ProgressBar = findViewById(R.id.pbTimer)
        val timeLeftTv: TextView = findViewById(R.id.tvTimeLeft)

        val savedTime = sharedPrefHelper.getDailyTime()
        if (savedTime > 0) {
            timeSelected = savedTime
            val hours = savedTime / 3600
            val minutes = (savedTime % 3600) / 60
            val seconds = savedTime % 60
            timeLeftTv.text = String.format("%02d:%02d:%02d", hours, minutes, seconds)
            progressBar.max = savedTime
        }

        if (intent.getBooleanExtra("fromAlarm", false) && timeSelected > 0) {
            startTimer(0)
        }

        addBtn.setOnClickListener { setTimeFunction() }
        startBtn.setOnClickListener { startTimerSetup() }
        resetBtn.setOnClickListener { resetTime() }
        addTimeTv.setOnClickListener { addExtraTime() }


        btnBack.setOnClickListener { // إضافة OnClickListener لـ imageView14
            val intent = Intent(this, MainActivity2::class.java) // إنشاء Intent للعودة لـ MainActivity2
            startActivity(intent) // بدء النشاط
            finish() // (اختياري) إنهاء هذا النشاط لكي لا يمكن الرجوع إليه بزر الرجوع الافتراضي
        }


    }

    private fun addExtraTime() {
        val progressBar: ProgressBar = findViewById(R.id.pbTimer)
        val timeLeftTv: TextView = findViewById(R.id.tvTimeLeft)
        if (timeSelected != 0) {
            timeSelected += 15
            sharedPrefHelper.saveDailyTime(timeSelected)
            progressBar.max = timeSelected
            timePause()
            startTimer(pauseOffSet)
            val currentTotalSeconds = timeSelected - timeProgress
            val hours = currentTotalSeconds / 3600
            val minutes = (currentTotalSeconds % 3600) / 60
            val seconds = currentTotalSeconds % 60
            timeLeftTv.text = String.format("%02d:%02d:%02d", hours, minutes, seconds)
            Toast.makeText(this, "15 seconds added", Toast.LENGTH_SHORT).show()
        }
    }

    private fun resetTime() {
        if (timeCountDown != null) {
            timeCountDown!!.cancel()
        }

        timeProgress = 0
        timeSelected = 0
        pauseOffSet = 0
        timeCountDown = null
        isStart = true

        val startBtn: Button = findViewById(R.id.btnPlayPause)
        startBtn.text = "Start"

        val progressBar = findViewById<ProgressBar>(R.id.pbTimer)
        progressBar.progress = 0

        val timeLeftTv: TextView = findViewById(R.id.tvTimeLeft)
        timeLeftTv.text = "00:00:00"

        sharedPrefHelper.clearDailyTime()
    }

    private fun timePause() {
        if (timeCountDown != null) {
            timeCountDown!!.cancel()
        }
    }

    private fun startTimerSetup() {
        val startBtn: Button = findViewById(R.id.btnPlayPause)
        if (timeSelected > timeProgress) {
            if (isStart) {
                startBtn.text = "Stop"
                startTimer(pauseOffSet)
                isStart = false
            } else {
                isStart = true
                startBtn.text = "Resume"
                timePause()
            }
        } else {
            Toast.makeText(this, "Enter the time", Toast.LENGTH_SHORT).show()
        }
    }

    private fun startTimer(pauseOffSetL: Long) {
        val progressBar = findViewById<ProgressBar>(R.id.pbTimer)
        val timeLeftTv: TextView = findViewById(R.id.tvTimeLeft)
        progressBar.progress = timeProgress

        timeCountDown = object : CountDownTimer(
            (timeSelected * 1000).toLong() - pauseOffSetL * 1000, 1000
        ) {
            override fun onTick(p0: Long) {
                val timeLeftSeconds = (p0 / 1000)
                val hours = timeLeftSeconds / 3600
                val minutes = (timeLeftSeconds % 3600) / 60
                val seconds = timeLeftSeconds % 60

                val formattedTime = String.format("%02d:%02d:%02d", hours, minutes, seconds)
                timeLeftTv.text = formattedTime
                progressBar.progress = timeSelected - timeLeftSeconds.toInt()
                pauseOffSet = timeSelected.toLong() - timeLeftSeconds
                timeProgress++
            }

            override fun onFinish() {
                resetTime()
                Toast.makeText(this@DailyTime, "Time's up!", Toast.LENGTH_SHORT).show()
                val intent = Intent(this@DailyTime, freeze_screen::class.java)
                startActivity(intent)
                finish()
            }
        }.start()
    }

    private fun setTimeFunction() {
        val timeDialog = Dialog(this)
        timeDialog.setContentView(R.layout.add_dialog)
        val timeSetHours = timeDialog.findViewById<EditText>(R.id.etGetHours)
        val timeSetMinutes = timeDialog.findViewById<EditText>(R.id.etGetMinutes)
        val timeSetSeconds = timeDialog.findViewById<EditText>(R.id.etGetSeconds)
        val timeLeftTv: TextView = findViewById(R.id.tvTimeLeft)
        val btnStart: Button = findViewById(R.id.btnPlayPause)
        val progressBar = findViewById<ProgressBar>(R.id.pbTimer)

        timeDialog.findViewById<Button>(R.id.btnOk).setOnClickListener {
            val hours = timeSetHours.text.toString().toIntOrNull() ?: 0
            val minutes = timeSetMinutes.text.toString().toIntOrNull() ?: 0
            val seconds = timeSetSeconds.text.toString().toIntOrNull() ?: 0

            if (hours == 0 && minutes == 0 && seconds == 0) {
                Toast.makeText(this, "Enter a time period", Toast.LENGTH_SHORT).show()
            } else {
                resetTime()
                val totalSeconds = (hours * 3600) + (minutes * 60) + seconds
                timeSelected = totalSeconds
                sharedPrefHelper.saveDailyTime(totalSeconds)
                progressBar.max = timeSelected

                val formattedTime = String.format("%02d:%02d:%02d", hours, minutes, seconds)
                timeLeftTv.text = formattedTime
                btnStart.text = "Start"

                scheduleDailyAlarm()
            }
            timeDialog.dismiss()
        }
        timeDialog.show()
    }

    private fun scheduleDailyAlarm() {
        val alarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(this, AlarmReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            this, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val calendar = Calendar.getInstance().apply {
            timeInMillis = System.currentTimeMillis()
            add(Calendar.DATE, 1) // بكرة
        }

        alarmManager.setRepeating(
            AlarmManager.RTC_WAKEUP,
            calendar.timeInMillis,
            AlarmManager.INTERVAL_DAY,
            pendingIntent
        )
    }

    override fun onDestroy() {
        super.onDestroy()
        if (timeCountDown != null) {
            timeCountDown?.cancel()
            timeProgress = 0
        }
    }
}
